/****
 * FILE: Use this file to manage node server listening.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include the db config, node & app.
 * DATE: April 02, 2019.
**/

const Http = require('http')
 // MySQL = require('mysql');

// APP INCU.
const app = require('./app');

const host = process.env.HOST || "localhost",
  port = process.env.PORT || 3000,
  user = process.env.MYSQL_USR || "root",
  password = process.env.MYSQL_PWD || "welcome@123",
  database = process.env.MYSQL_DATABASE || "pan_linuxapp";

/*
// Connection Configurations.
const con = MySQL.createConnection({
  host: host,
  user: user,
  password: password,
  database: database
});

// Connect To Database.
con.connect(function(err) {
  if (err) {
    console.log("UNABLE TO CONNECT DB...");
  } 
  else {
    const server = Http.createServer(app);
    server.listen(port, () => console.log(`Listening at: http://localhost:${port}/`));
  }
})
*/
const server = Http.createServer(app);
server.listen(port, () => console.log(`Listening at: http://localhost:${port}/`));