# Linux Application

This project was generated with [Node](https://nodejs.org/en/download/) version 10.15.3.

## RESTful API with Node-express:

Technology use in this architecture - 
* NodeJs - v10.15.3
* Npm - 6.4.1
* Pm2 - 
* Nodemon - 1.18.10+
* Express - 4.16.4+
* MySQL - 2.16.0+
	* Get [MySQL](https://www.npmjs.com/package/mysql) for Angular.
	* Get [MySQL](https://support.rackspace.com/how-to/installing-mysql-server-on-ubuntu/) for Linux. 
	* Get [MySQL](https://dev.mysql.com/doc/refman/8.0/en/windows-installation.html) for Window.
* Morgan - 1.9.1+
* BodyParser - 1.18.3+

## Create a new repository on the command line:

Clone git repository on your existing system, when you want to get whole code from git.

* git clone http://git.impressicocrm.com/digital-signage/ds-linux-server.git
* git status
* cd ds-linux-server
* npm install
* Use if PORT(3000) already in use:
	* For Linux - 
		* fuser 3000/tcp
		* fuser -k 3000/tcp
		* npx nodemon
	* For Windows - 
		* netstat -ano | findstr :3000
		* tskill 5584
		* npx nodemon
* Else use -
	* npx nodemon

## Push an existing repository from the command line:

Push your code from local to git.

* git remote add origin http://git.impressicocrm.com/digital-signage/ds-linux-server.git
* git commit -m "<message here...>"
* git push -u origin master

## Development server

Run `npx nodemon` for a dev server. Navigate to `http://localhost:3000/`. The app will automatically reload if you change any of the source files.

## Use pm2 server manager:
In Progress...

## Work Done:

* Structure Configuration Done.

## Further help

To get more help on the Angular CLI use `npm help` or go check out the [Node DOCS](https://nodejs.org/en/docs/).