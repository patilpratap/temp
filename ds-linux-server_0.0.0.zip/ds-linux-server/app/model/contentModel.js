 /****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include da connection & manage db relation's.
 * DATE: April 01, 2019.
**/

'user strict';

const _ = require('lodash'),
  _contentApiUrl='/content/',
  BaseModel = require("./baseModel"),
  exec = require('child_process').exec;
  

exports.setHeaders = (customerId, authToken) => {
  BaseModel.setHeader({
    "customerid": customerId,
    "authorization": authToken
  })
}

exports.fetchHeader = () => {
  return BaseModel.getHeader()
}

exports.getContentApiUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType +_contentApiUrl;
}

exports.saveServerRecordsInJson = (fileName, recordObj) => {
  return BaseModel.saveRecordsInJsonFile(fileName, recordObj)
}

exports.getServerRecordsFromJson = (fileName) => {
  return BaseModel.getRecordsFromJsonFile(fileName)
}

exports.getDistinctLayoutsFromScheduleInfo = (layouts, key) => {
  let distinctLayout =  _.uniqBy(layouts, key);
  return distinctLayout;
}

exports.getDistinctContentsFromLayoutsInfo = (contentObj, cid, vid) => {
  var filterObj = contentObj.filter(function (res) {
    var key = res[cid] + '|' + res[vid]
    if (!this[key]) {
        this[key] = true
        return true
    }
  }, Object.create(null))
  return filterObj
}



