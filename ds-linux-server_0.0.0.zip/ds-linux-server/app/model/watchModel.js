/****
 * FILE: Use this file for modeling watcher.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can manage modeling on watcher.
 * DATE: April 12, 2019.
**/

'user strict';

const BaseModel = require("./baseModel")

exports.getDeviceInformations =(fileName) => {
  return BaseModel.getRecordsFromJsonFile(fileName)
}