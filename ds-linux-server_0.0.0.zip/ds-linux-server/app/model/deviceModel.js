/****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include da connection & manage db relation's.
 * DATE: April 05, 2019.
**/

'user strict';

const _ = require('lodash'),
  BaseModel = require("./baseModel.js"),
  landscapeUrl='/customer/v2/default-planogram-image?download=true',
	potraitUrl='/customer/v2/default-planogram-portrait-image?download=true',
  _serverTimeUrl = '/time';
  _pushAcknowledgeUrl = '/push/acknowledge',
  _dataCollectionConfigUrl = '/dataCollection/v2',
  _deviceMeUrl = '/device/me',
  path = require('path'),
  fs = require('fs');

exports.getCustomerDefaultImg = function(url,headers) {
  return axios.get(url,{headers: headers});
}

exports.getDefaultImageUrl = (isUrlTypeLandscape) => {
  var apiUrl = '',environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  if(isUrlTypeLandscape == 'true' || isUrlTypeLandscape == true)
    apiUrl = environmentType+landscapeUrl;
  else
    apiUrl = environmentType+potraitUrl;
  return apiUrl;
}

exports.saveRecordsInJson = (fileName, recordObj) => {
  return BaseModel.saveRecordsInJsonFile(fileName, recordObj)
}

exports.getRecordsFromJson = (fileName) => {
  return BaseModel.getRecordsFromJsonFile(fileName)
}

exports.getServerTimeUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType+_serverTimeUrl;
}

exports.getPushAcknowledgeUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType+_pushAcknowledgeUrl;
}

exports.getDataCollectionApiUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType+_dataCollectionConfigUrl;
}

exports.deleteFileFromFolder = (folder,file) => {
  let absolutePath = path.resolve(folder + '/' + file);
  try {
    fs.unlinkSync(absolutePath)
    //file removed
  } catch(err) {
    console.error(err)
  }
}

exports.getDeviceMeApiUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType+_deviceMeUrl;
}

exports.getResponseFromSever =  (url, header, params) => {
  return  BaseModel.getResponseFromServer(url,header,params)
}

exports.setHeaders = (customerId, authToken) => {
  BaseModel.setHeader({
    "customerid": customerId,
    "authorization": authToken
  })
}

exports.fetchHeader = () => {
  return BaseModel.getHeader()
}

exports.saveRecordsInLogFile = (fileName, recordObj) => {
  let json =[];
  json =  BaseModel.getLogFromJsonFile(fileName);
  if(json.length){
    json.push(recordObj[0])
  }else{
    json = recordObj;
  }
  return BaseModel.updateLogToJsonFile(fileName, json)
}

exports.getRecordsFromLogFile = (fileName) => {
  return BaseModel.getLogFromJsonFile(fileName)
}