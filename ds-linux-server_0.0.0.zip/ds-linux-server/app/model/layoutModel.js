 /****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include da connection & manage db relation's.
 * DATE: April 01, 2019.
**/

'user strict';

const _ = require('lodash'),
  _layoutApiUrl='/layout/device/',
  BaseModel = require("./baseModel");

exports.setHeaders = (customerId, authToken) => {
  BaseModel.setHeader({
    "customerid": customerId,
    "authorization": authToken
  })
}

exports.fetchHeader = () => {
  return BaseModel.getHeader()
}

exports.getLayoutApiUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType +_layoutApiUrl;
}

exports.saveServerRecordsInJson = (fileName, recordObj) => {
  return BaseModel.saveRecordsInJsonFile(fileName, recordObj)
}

exports.getServerRecordsFromJson = (fileName) => {
  let res =  BaseModel.getRecordsFromJsonFile(fileName);
   return res
  /*return new Promise(function(resolve,reject) {
    
  });*/
}

exports.getDistinctLayoutsFromScheduleInfo = (layouts) => {
  let distinctLayout =  _.uniqBy(layouts, 'layoutId');
  return distinctLayout;
}

