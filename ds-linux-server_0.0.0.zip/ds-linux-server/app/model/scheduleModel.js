 /****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include da connection & manage db relation's.
 * DATE: April 01, 2019.
**/

'user strict';

const _ = require('lodash'),
  BaseModel = require("./baseModel"),
  _scheduleApiUrl='/schedule/';

exports.setHeaders = (customerId, authToken) => {
  BaseModel.setHeader({
    "customerid": customerId,
    "authorization": authToken
  })
}

exports.fetchHeader = () => {
  return BaseModel.getHeader()
}

exports.getScheduleApiUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType +_scheduleApiUrl;
}

exports.getResponseFromSever =  (url, header, params) => {
  return  BaseModel.getResponseFromServer(url,header,params)
}

exports.saveServerRecordsInJson =  (fileName, recordObj) => {
  return BaseModel.saveRecordsInJsonFile(fileName, recordObj)
}

exports.getServerRecordsFromJson =  (fileName) => {
  return BaseModel.getRecordsFromJsonFile(fileName)
}
