/****
 * FILE: Use this file to manage node/mysql connection.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include mysql & configure hosting information's.
 * DATE: April 01, 2019.
**/

'user strict';
/*
const mysql = require('mysql');

const host = process.env.HOST,
  user = process.env.MYSQL_USR,
  password = process.env.MYSQL_PWD,
  database = process.env.MYSQL_DATABASE;

var knex = require('knex')({
    client: 'mysql',
    connection: {
      host: host,
      user: user,
      password: password,
      database: database
    }
  });

function Connection() {
  this.knex = knex;
}

module.exports = new Connection();
*/