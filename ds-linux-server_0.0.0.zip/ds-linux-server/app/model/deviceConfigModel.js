/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can create function to get and save device config details.
 * DATE: April 09, 2019.
**/


'user strict';

const _ = require('lodash'), 
	BaseModel = require("./baseModel.js");
 	_deviceConfigApiUrl='/deviceConfig/';

exports.getDeviceConfigApiUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType +_deviceConfigApiUrl;
}

exports.saveServerRecordsInJson = (fileName, recordObj) => {
  return BaseModel.saveRecordsInJsonFile(fileName, recordObj)
}

exports.getServerRecordsFromJson = (fileName) => {
  return BaseModel.getRecordsFromJsonFile(fileName)
}
