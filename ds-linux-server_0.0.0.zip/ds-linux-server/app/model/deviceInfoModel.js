 /****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include da connection & manage db relation's.
 * DATE: April 01, 2019.
**/

'user strict';

const _ = require('lodash'),
  BaseModel = require("./baseModel.js"),
  _setLocalServerUrl = '/device/set-local-server',
  _apiVersionUrl = '/api-version'

let _deviceConfigurationModel = {
  "osName":null,
  "osVersion":null,
  "brandName":null,
  "modelName":null,
  "deviceManufacturer":null,
  "screenResolution":null,
  "networkType":"NA",
  "networkConnection":null,
  "internetStatus":null,
  "macAddress": 'NA',
  "wifiMacAddress": "NA",
  "ipAddress": null,
  "deviceToken":null,
  "customerId": null,
  "deviceIdentifier":null,
  "deviceId":null,
  "appVersion":null,
  "diskMemoryTotal": null,
  "diskMemoryUsed": null,
  "diskMemoryAvailable": null,
  "appMemoryTotal": null,
  "appMemoryUsed": null,
  "appMemoryAvailable": null,
  "custCode": null,
  "boardName": null,
  "localServerIP":""
}

let _apiVersionModel = {
  "cmsServer":"",
  "localServer":""
}

exports.setDeviceConfigurationModel = (params) => {
  // appVersion, wifiMacAddress.
  _deviceConfigurationModel.appVersion = "NA"
  // deviceIdentifier.
  if (params.uniqueIdentifier) {
    _deviceConfigurationModel.deviceIdentifier = params.uniqueIdentifier
  }
  // osName, release.
  if (params.distro) {
    _deviceConfigurationModel.osName = params.distro
  }
  if (params.release) {
    _deviceConfigurationModel.osVersion = params.release
  }
  // brandName, modelName, deviceManufacturer.
  if (params.brand) {
    _deviceConfigurationModel.brandName = params.brand
  }
  if (params.model) {
    _deviceConfigurationModel.modelName = params.model
  }
  if (params.manufacturer) {
    _deviceConfigurationModel.deviceManufacturer = params.manufacturer
  }
  // networkType, macAddress, ipAddress, networkConnection.
  if (params.type) {
    let type = 'NA';
    if(params.type == 'wired'){
      type = 'Ethernet' 
    }else if(params.type == 'wireless'){
      type = 'Wifi'
    }
    _deviceConfigurationModel.networkType = type
  }
  if (params.mac) {
    if(_deviceConfigurationModel.networkType == 'Ethernet'){
      _deviceConfigurationModel.macAddress = params.mac
    }else if(_deviceConfigurationModel.networkType == 'Wifi'){
      _deviceConfigurationModel.wifiMacAddress = params.mac
    }
  }
  if (params.ip4) {
    _deviceConfigurationModel.ipAddress = params.ip4
  }
  if (params.operstate) {
    if (params.operstate == 'up') {
      _deviceConfigurationModel.internetStatus = "Connected"
      _deviceConfigurationModel.networkConnection = "Connected"
    }
    else {
      _deviceConfigurationModel.internetStatus = "Disconnected"
      _deviceConfigurationModel.networkConnection = "Disconnected"
    }
  }
  // screenResolution.
  if(params.resolutionx && params.resolutiony ){
    _deviceConfigurationModel.screenResolution = params.resolutionx +'*'+ params.resolutiony
  }
  if (params.currentResX && params.currentResY) {
    _deviceConfigurationModel.screenResolution = params.currentResX +'*'+ params.currentResY
  }
  // appMemoryTotal, appMemoryAvailable, appMemoryUsed.
  if (params.appMemoryTotal) {
    _deviceConfigurationModel.appMemoryTotal = params.appMemoryTotal
  }
  if (params.appMemoryUsed) {
    _deviceConfigurationModel.appMemoryUsed = params.appMemoryUsed
  }
  if (params.appMemoryAvailable) {
    _deviceConfigurationModel.appMemoryAvailable = params.appMemoryAvailable
  }
  // diskMemoryTotal, diskMemoryUsed, diskMemoryAvailable.
  if (params.diskMemoryTotal) {
    _deviceConfigurationModel.diskMemoryTotal = params.diskMemoryTotal
  }
  if (params.diskMemoryUsed) {
    _deviceConfigurationModel.diskMemoryUsed = params.diskMemoryUsed
  }
  if (params.diskMemoryAvailable) {
    _deviceConfigurationModel.diskMemoryAvailable = params.diskMemoryAvailable
  }
  if (params.boardName) {
    _deviceConfigurationModel.boardName = params.boardName
  }

}

exports.getDeviceConfigurationModel = () => {
  return _deviceConfigurationModel
}

exports.resetDeviceConfigurationModel = () => {
  _deviceConfigurationModel.deviceToken=null;
  _deviceConfigurationModel.customerId=null;
  _deviceConfigurationModel.deviceId=null;
  _deviceConfigurationModel.custCode=null;
  _deviceConfigurationModel.localServerIP="";
}

exports.saveClientRecordsInJson = (fileName, recordObj) => {
  return BaseModel.saveRecordsInJsonFile(fileName, recordObj)
}

exports.getClientRecordsFromJson = (fileName) => {
  return BaseModel.getRecordsFromJsonFile(fileName)
}

exports.getLocalServerUrl = () => {
  return BaseModel.getServerEnvironment() +_setLocalServerUrl;
}

exports.getApiVersionUrl = () => {
  let environmentType = '',
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
  environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
  return environmentType +_apiVersionUrl;
}

exports.getApiVersionModel = () =>{
  return _apiVersionModel;
}

exports.setApiVersionModel = (apiversionRes,internetStatus) =>{
  if(internetStatus == 'up'){
    _apiVersionModel.cmsServer = 'Connected'
    if(apiversionRes.localServer == 'true' || apiversionRes.localServer == true){
      _apiVersionModel.localServer = 'Connected';
    }else if(apiversionRes.localServer == 'error'){
      _apiVersionModel.localServer = 'Disconnected';
    }
    else{
      _apiVersionModel.localServer = 'NA';
    }
  }else{
    clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
    _apiVersionModel.cmsServer = 'Disconnected';
    if(clientInfo.localServerIP != ""){
      _apiVersionModel.localServer = 'Disconnected';
    }else{
      _apiVersionModel.localServer = 'NA';
    }
  }
}