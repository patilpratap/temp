 /****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include da connection & manage db relation's.
 * DATE: April 01, 2019.
**/

'user strict';

