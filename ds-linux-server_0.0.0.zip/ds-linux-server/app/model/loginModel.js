 /****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include db connection & manage db relation's.
 * DATE: May 28, 2019.
**/

'user strict';

const _ = require('lodash'),
  BaseModel = require("./baseModel.js"),
  _deviceLoginUrl = '/device/login';
  _deviceOnboardUrl = '/device/onboarding/'

  exports.getDeviceLoginUrl = () => {
    let environmentType = '',
      clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
    environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
    return environmentType+_deviceLoginUrl;
  }

  exports.saveRecordToSever =  (url, header, params) => {
    return  BaseModel.saveDataToServer(url,header,params)
  }

  exports.getDeviceOnboardUrl = () => {
    let environmentType = '',
      clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
    environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
    return environmentType+_deviceOnboardUrl;
  }

  exports.getResponseFromSever =  (url, header, params) => {
    return  BaseModel.getResponseFromServer(url,header,params)
  }