/****
 * FILE: Use this file for collecting basic fun.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include some basic common funcrtions.
 * DATE: April 07, 2019.
**/

'user strict';

const fs = require('fs'),
  os = require('os'),
  _ = require('lodash'),
  Path = require('path'),
  axios = require("axios"),
  shell = require('shelljs'),
  moment = require('moment'),
  sysInfo = require('systeminformation'),
  logModel = require('./logModel.js');
  _filePath = "assets/json/",
  _errorLogPath = "assets/log/",
  _contentPath = "assets/content/",
  _deviceImagePath = "assets/content/device/",
  // _environment = 'https://piqa1server.impressicocrm.com';
  _environment = 'https://pidev2.impressicocrm.com/api',
  exec = require('child_process').exec;

const archiver = require('archiver');
let header = {
  'Content-Type':'application/json',
	'Authorization':'',
	'customerId':''
}/*,
errorLog = {
  'type':'',
  'url':'',
  'message':'',
  'code':''
}*/

exports.saveFilesInContent = () => {
  
}

exports.getContentPath = () => {
  return _contentPath
}

exports.saveRecordsInJsonFile = (fileName, recordObj) => {
  if(!fs.existsSync(_filePath)) {
    shell.mkdir('-p', _filePath)
  }
  try {
    let path = _filePath+fileName
    fs.writeFileSync(path, JSON.stringify(recordObj), 'utf8', function (err) {
      if (err) {
        // console.log("An error occured while writing JSON Object to File.")
      }
      else {
        return "JSON file has been saved."
        // console.log("JSON file has been saved.")
      }
    })
    //return "JSON file has been saved."
  }
  catch (err) {
    return err
  }
}

exports.getRecordsFromJsonFile = (fileName) => {
  let path = _filePath+fileName
  const exist = statPath(path)
  if(exist && exist.isFile()) {
    //return require("../../"+path)
    delete require.cache[require.resolve("../../"+path)];
    return JSON.parse(fs.readFileSync(path, 'utf8'))
    
  } 
  else {
    return "File does not exist."
  }
}

function statPath(path) {
  try {
    return fs.statSync(path)
  } 
  catch (ex) {}
  return false
}

exports.getDevicePath = () => {
  return _deviceImagePath
}

exports.getDeviceHosting = () => {
  return "http://"+ os.hostname() +":3000"
}

exports.setHeader = (req) => {
  if (req.authorization) {
    header['Authorization'] = "Bearer "+ req.authorization
  }
  else {
    delete header.Authorization
  }
  if (req.customerid) {
    header['customerId'] = req.customerid
  }
  else {
    delete header.customerId
  }
}

exports.getHeader = () => {
  return header;
}

exports.getResponseFromServer = function(url,headers,params) {
  return axios.get(url,{headers: headers,params:params});
}

exports.getJsonFilePath = () => {
  return _filePath
}

exports.getServerEnvironment = () => {
  return _environment;
}

exports.downloadFile = async (_dirPath, mediaUrl,fileName,apiUrl,contentId) => {
  if(!fs.existsSync(_dirPath)) {
    shell.mkdir('-p', _dirPath)
  }
  const path = Path.resolve(__dirname, '../../'+_dirPath, fileName)
  try{
    const url=mediaUrl;
    if(url){
      const response = await axios({
        url,
        method: 'GET',
        responseType: 'stream'
      })
      const writer = fs.createWriteStream(path)
      response.data.pipe(writer)

      return new Promise((resolve, reject) => {
        writer.on('finish', function(resp){
          // logModel.updateLastContentDownloadTime();
          // logModel.updateDataCollectionLog(false)
          resolve()
        })
        writer.on('error', function(err){
          logModel.isContentDownloadFailed = true;
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.DOWNLOAD_FAILED,apiUrl,contentId,0);
          reject();
        })
      })
    }
  }catch(err){
   // console.log('download issue==>',err)
  }
}

exports.successResponse = function(res,data){
  res.send({
    "code": 200,
    "name": "SuccessfullyFetched",
    "message": "Record Fetched",
    "result": data
  })
}

exports.errorResponse = function(res,data){
  res.send(data)
}

exports.responseError = function(res,statusCode,data){
  res.status(statusCode).send(data)
}

exports.updateLogToJsonFile = function(fileName, recordObj){
  if(!fs.existsSync(_errorLogPath)) {
    shell.mkdir('-p', _errorLogPath)
  }
  try {
    let path = _errorLogPath+fileName
    fs.writeFileSync(path, JSON.stringify(recordObj), 'utf8', function (err) {
      if (err) {
        return err
        //console.log("An error occured while writing JSON Object to File.")
      }
      else {
        return "Log file has been saved."
        // console.log("JSON file has been saved.")
      }
    })
    
  }
  catch (err) {
    return err
  }
}

exports.getLogFromJsonFile = function(fileName) {
  let path = _errorLogPath+fileName
  const exist = statPath(path)
  if(exist && exist.isFile()) {
   // return require("../../"+path)
   delete require.cache[require.resolve("../../"+path)];
   return JSON.parse(fs.readFileSync(path, 'utf8'))
  } 
  else {
    return false
  }
}

exports.getNetworkInformation = async function(){
  try {
    const data = await sysInfo.networkInterfaces();
    let osType = os.platform();
    let response;
    if(data.length == 2 || data.length == 3){
      if(osType == 'linux'){
        response = data[1]
      }else{
        response = data[0]
      }
    }else{
      response = data[0]
    }
    return response.operstate
  } 
  catch (e) {
    console.log(e)
  }
}

exports.updateDataToServer = function(url,data,headers,params) {
  //return axios.get(url,{headers: headers,params:params});
  return axios({
    method: 'put',
    url: url,
    headers: headers,
    data: data
  });
}

exports.saveDataToServer = function(url,data,headers,params) {
  //return axios.get(url,{headers: headers,params:params});
  return axios({
    method: 'post',
    url: url,
    headers: headers,
    data: data
  });
}

exports.noInternetResponse = function(res){
  res.send({
    "code": 404,
      "name": "Offline",
      "message": "Internet connection not available",
      "result": null
  })
}

exports.saveRecordsInFile = (fileName, recordObj) => {
  if(!fs.existsSync(_errorLogPath)) {
    shell.mkdir('-p', _errorLogPath)
  }
  try {
    let path = _errorLogPath+fileName
    fs.writeFileSync(path, recordObj, 'utf8', function (err) {
      if (err) {
        // console.log("An error occured while writing JSON Object to File.")
      }
      else {
        return "File has been saved."
        // console.log("JSON file has been saved.")
      }
    })
    //return "JSON file has been saved."
  }
  catch (err) {
    return err
  }
}

exports.getRecordsFromFile = (fileName) => {
  let path = _errorLogPath+fileName
  const exist = statPath(path)
  if(exist && exist.isFile()) {
    delete require.cache[require.resolve("../../"+path)];
    return fs.readFileSync(path, 'utf8')    
  } 
  else {
    return false;
  }
}

exports.responseSuccess = function(res,code,name,msg,data){
  res.send({
    "code": code,
      "name": name,
      "message": msg,
      "result": data
  })
}

exports.getLogPath = () => {
  return _errorLogPath;
}

exports.zipDeviceLog = async function(){
  return new Promise((resolve, reject) => {
    try{
      // create a file to stream archive data to.
      var output = fs.createWriteStream(_errorLogPath + '/PDSLogFile.zip');
      var archive = archiver('zip', {
        zlib: { level: 9 } // Sets the compression level.
      });

      // listen for all archive data to be written
      // 'close' event is fired only when a file descriptor is involved
      output.on('close', function() {
        resolve();
      });

      // This event is fired when the data source is drained no matter what was the data source.
      // It is not part of this library but rather from the NodeJS Stream API.
      // @see: https://nodejs.org/api/stream.html#stream_event_end
      output.on('end', function() {
        resolve();
      });

      // good practice to catch warnings (ie stat failures and other non-blocking errors)
      archive.on('warning', function(err) {
        if (err.code === 'ENOENT') {
          reject();
        } else {
          reject();
        }
      });

      // good practice to catch this error explicitly
      archive.on('error', function(err) {
        reject();
      });

      // pipe archive data to the file
      archive.pipe(output);

      // append a file from stream
      var file1 = _errorLogPath + '/PDSLogFile.txt';
      archive.append(fs.createReadStream(file1), { name: 'PDSLogFile.txt' });
        // finalize the archive (ie we are done appending files but streams have to finish yet)
        // 'close', 'end' or 'finish' may be fired right after calling this method so register to them beforehand
      archive.finalize();
    }
    catch(err){
      reject();
    }
  })  
}

exports.getFileUpdatedDate = (fileName) => {
    let path = _errorLogPath+fileName
    const stats = fs.statSync(path);
    var unixTimestamp = Math.round(new Date(stats.mtime).getTime());
    return unixTimestamp;
}

exports.getFileCreatedDate = (fileName) => {
    let path = _errorLogPath+fileName
    const stats = fs.statSync(path);
    var unixTimestamp = Math.round(new Date(stats.birthtime).getTime());
    return unixTimestamp;
}

exports.getLogPath = () => {
  return _errorLogPath
}

exports.getFilesizeInBytes = (filename) =>{
  let path = _errorLogPath+filename
  if (!fs.existsSync(path)) {
    fs.writeFileSync(path, '', 'utf8', function (err) {
      if (err) {
        return false;
      }
      else {
        // console.log("JSON file has been saved.")
      }
    })
  }  
  const stats = fs.statSync(path);
  const fileSizeInBytes = stats.size;
  return fileSizeInBytes;
}

exports.getDeviceAudioStatus  = function(){
  return new Promise(function(resolve,reject) {
    getVolumn(function(output){
      let audioStatus = (output.trim() == 'on') ? true:false ;
      resolve(audioStatus);
    })
  });
}

function getVolumn(callback){
  exec("amixer get Master | grep 'Right:' | awk -F'[][]' '{ print $4 }'", function(error, stdout, stderr){ 
    callback(stdout); 
  });
}
