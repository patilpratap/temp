 /****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include db connection & manage db relation's.
 * DATE: May 28, 2019.
**/

'user strict';

const _ = require('lodash'),
  BaseModel = require("./baseModel.js"),
  _deviceregistrationUrl = '/unregistered-device';
  _customerIdMaskUrl = '/customer/id-from-mask'

  exports.getDeviceRegistrationUrl = () => {
    let environmentType = '',
      clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
    environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
    return environmentType+_deviceregistrationUrl;
  }

  exports.saveRecordToSever =  (url, header, params) => {
    return  BaseModel.saveDataToServer(url,header,params)
  }

  exports.getCustomerIdMaskUrl = () => {
    let environmentType = '',
      clientInfo = BaseModel.getRecordsFromJsonFile("client-info.json");
    environmentType = (clientInfo.localServerIP == "") ? BaseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
    return environmentType+_customerIdMaskUrl;
  }

  exports.getResponseFromSever =  (url, header, params) => {
    return  BaseModel.getResponseFromServer(url,header,params)
  }