/****
 * FILE: Use this file for modeling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include db connection & manage db relation's.
 * DATE: Jun 06, 2019.
**/

'user strict';

const _ = require('lodash'),
  baseModel = require("./baseModel.js"),
  _deviceErrorUrl = '/device/error',
  _deviceLogUrl = '/device-logs',
  moment = require('moment');
  path = require('path'),
  _contentPlaybackLogUrl = '/analytics/content-playback';

  exports.deviceErrorCode = {
    'UNKNOWN_ERROR' : 1,
    'API_500_ERROR_CODE' : 2,
    'STORAGE_FULL' : 3,
    'OUT_OF_MEMORY' : 4,
    'INTERNET_NOT_AVAILABLE' : 5,
    'PANEL_CONNECTIVITY' : 6,
    'LOCAL_SERVER_CONNECTIVITY' : 7,
    'USB_FILE_ENCRYPTION' : 8,
    'DOWNLOAD_FAILED' : 9
  };

  var isContentDownloadFailed = false;
   
  exports.getDeviceErrorApiUrl = function(){
    let environmentType = '',
    clientInfo = baseModel.getRecordsFromJsonFile("client-info.json");
    environmentType = (clientInfo.localServerIP == "") ? baseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
    return environmentType+_deviceErrorUrl;
  }

  exports.getRecordsFromJson = (fileName) => {
    return baseModel.getLogFromJsonFile(fileName)
  }

  exports.saveRecordToSever =  (url, header, params) => {
    return  baseModel.saveDataToServer(url,header,params)
  }

  exports.updateDeviceErrorLog = function(errorCode,url,contentId,panelId){
    updateDataCollectionLog(true);
    let jsonArray=[],deviceJson,
    deviceErrorModel = {
      'errorCode' : 1,
      'errorDescription' : "",
      'timestamp' : "",
      'url':"",
      'contentId' : 0,
      'panelId' : 0
    },
    deviceError = {
      'deviceErrors':[]
    }
    if(errorCode){
      deviceErrorModel.errorCode = errorCode;
      deviceErrorModel.errorDescription = setDescription(errorCode);
    }
    if(url){
      deviceErrorModel.url = url
    }
    if(contentId){
      deviceErrorModel.contentId = contentId
    }
    if(panelId){
      deviceErrorModel.panelId = panelId
    }
    deviceErrorModel.timestamp = moment().unix() * 1000;
    deviceJson = baseModel.getLogFromJsonFile("device-error-log.json");
    if(!deviceJson.deviceErrors){
      jsonArray.push(deviceErrorModel)
    }else{
      jsonArray = deviceJson.deviceErrors;
      jsonArray.push(deviceErrorModel)
    }
    deviceError.deviceErrors = jsonArray;
    baseModel.updateLogToJsonFile("device-error-log.json",deviceError);
  }

  exports.setLog = function(isError, url, err){
    var jsonArray=[],
    errorLog = {
      'type':'',
      'url':'',
      'message':'',
      'code':''
    };
    if(isError){
      if(err && err.code){
        errorLog.code = err.code;
      }
      if(err && err.message){
        errorLog.message = err.message;
      }
      if(err && err.name){
        errorLog.type = err.name;
      }else
        errorLog.type = 'error';
      if(url){
        errorLog.url = url+" "+moment().format("DD/MM/YYYY")+" "+moment().format("HH:mm:ss");
      }
    }else{
      errorLog.type = 'success'
      errorLog.code = '200';
      errorLog.message = 'Success';
      errorLog.url = url+" "+moment().format("DD/MM/YYYY")+" "+moment().format("HH:mm:ss");
    }
    json = baseModel.getLogFromJsonFile("error-log.json");
    if(!json){
      jsonArray.push(errorLog)
    }else{
      jsonArray = json;
      jsonArray.push(errorLog)
    }
    baseModel.updateLogToJsonFile("error-log.json",jsonArray)
    
  }

  function setDescription(errorCode){
    let description='';
    if(errorCode == 2){
      description = 'Internal server error';
    }else if(errorCode == 3){
      description = 'Storage full error';
    }else if(errorCode == 4){
      description = 'Out of memory error';
    }else if(errorCode == 5){
      description = 'Internet not available';
    }else if(errorCode == 6){
      description = 'Panel connectivity error';
    }else if(errorCode == 7){
      description = 'Local server connectivity error';
    }
    else if(errorCode == 8){
      description = 'USB file encryption error';
    }
    else if(errorCode == 9){
      description = 'Download Failed';
    }else{
      description = 'Unknown error';
    }
    return description;
  }
  
  exports.getRecordsFromFile = (fileName) => {
    return baseModel.getRecordsFromFile(fileName)
  }

  exports.deleteFileFromFolder = (folder,file) => {
    let absolutePath = path.resolve(folder + '/' + file);
    try {
      fs.unlinkSync(absolutePath)
      //file removed
    } catch(err) {
     // console.log('err=======================>',err)
    }
  }
  exports.getDeviceLogApiUrl = function(){
    let environmentType = '',
    clientInfo = baseModel.getRecordsFromJsonFile("client-info.json");
    environmentType = (clientInfo.localServerIP == "") ? baseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
    return environmentType+_deviceLogUrl;
  }

  exports.getContentPlaybackLogApiUrl = function(){
    let environmentType = '',
    clientInfo = baseModel.getRecordsFromJsonFile("client-info.json");
    environmentType = (clientInfo.localServerIP == "") ? baseModel.getServerEnvironment() : "http://"+clientInfo.localServerIP;
    return environmentType+_contentPlaybackLogUrl;
  }

  exports.saveRecordsInLogFile = (fileName, recordObj) => {
    let json =[];
    json =  baseModel.getLogFromJsonFile(fileName);
    if(json.length){
      json.push(recordObj[0])
    }else{
      json = recordObj;
    }
    return baseModel.updateLogToJsonFile(fileName, json)
  }

  exports.getRecordsFromLogFile = (fileName) => {
    return baseModel.getLogFromJsonFile(fileName)
  }

  updateDataCollectionLog = async function(deviceEncounteredError){
    let jsonArray=[],
    dataCollectionModel = {
      "lastSyncTime":null,
      "ipAddress":"",
      "deviceEncounteredError":null,
      "isDeviceAudioEnabled":null,
      "timeOfStatus":null,
      "isDeviceDown":false,
      "currentBuildVersion":"1.0.0.0",
      "timeZone":null,
      "deviceAdditionalInfo":null
    }
    dataCollectionLog = baseModel.getLogFromJsonFile("data-collection-log.json");
    if(!dataCollectionLog){
      dataCollectionModel.lastSyncTime = moment().unix() * 1000;
    }else{
      if(isContentDownloadFailed || deviceEncounteredError){
        dataCollectionModel.lastSyncTime = dataCollectionLog[dataCollectionLog.length - 1].lastSyncTime;
      }else{
        lastSyncTimeJson = baseModel.getLogFromJsonFile("content-download-time.json")
        dataCollectionModel.lastSyncTime = (lastSyncTimeJson != false) ? lastSyncTimeJson.lastSyncTime : moment().unix() * 1000;
      }
    }
    deviceInfo =  baseModel.getRecordsFromJsonFile("client-info.json");
    await baseModel.getDeviceAudioStatus()
    .then(function(audioStatus){
      dataCollectionModel.isDeviceAudioEnabled = audioStatus;
    });
    dataCollectionModel.ipAddress = deviceInfo.ipAddress;
    dataCollectionModel.deviceEncounteredError = deviceEncounteredError;
    dataCollectionModel.timeOfStatus = moment().unix() * 1000;
    if(!dataCollectionLog){
      jsonArray.push(dataCollectionModel)
    }else{
      jsonArray = dataCollectionLog;
      jsonArray.push(dataCollectionModel)
    }
    baseModel.updateLogToJsonFile("data-collection-log.json",jsonArray);
  }

  exports.updateLastContentDownloadTime = function(){
    let data = {
      "lastSyncTime" : moment().unix() * 1000
    }
    baseModel.updateLogToJsonFile("content-download-time.json",data)
  }

  exports.updateDataCollectionLog = updateDataCollectionLog;
  exports.isContentDownloadFailed = isContentDownloadFailed;