/****
 * FILE: Use this file for controlling wather feature..
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can manage watcher feature like - 
 *      1. .
 * DATE: April 12, 2019.
**/

'use strict';

let _ = require('lodash'),
  layoutObj = require("./layoutController"),
  WathModel = require("../model/watchModel"),
  contentObj = require("./contentController"),
  scheduleObj = require("./scheduleController"),
  deviceObj = require("./deviceController"),
  intervalObj, deviceId, authToken, customerId;

exports.startWatchers = (req, res) => {
  const clientConfMedel = WathModel.getDeviceInformations("client-info.json");
  if (typeof clientConfMedel == "object") {
    deviceId = clientConfMedel.deviceId, authToken = clientConfMedel.deviceToken, customerId = clientConfMedel.customerId;
    if (deviceId && customerId && authToken) {
      //getSchedule()
      downloadCustomerLandscapeImage();
      //setTimeout(getLayouts, 3000)
      //setTimeout(getContent, 5000)
      setWatcher()
      console.log("...END...")
    }
  }

  res.send({
    "code": 200,
    "name": "WatcherModel",
    "message": "Watcher is start working.",
    "result": null
  })
}

exports.stopWatchers = (req, res) => {
  clearInterval(intervalObj);
  res.send({
    "code": 200,
    "name": "WatcherModel",
    "message": "Watcher is stop working.",
    "result": null
  })
}

function getSchedule () {
  if (deviceId && customerId && authToken) {
    scheduleObj.getScheduleDetailsFromServer(deviceId, customerId, authToken)
    .then(scheduleResp =>{
      getLayouts();
    })
    
  }
}

function getLayouts () {
  console.log("...Layout Called...")
  if (deviceId && customerId && authToken) {
    layoutObj.getLayoutDetailsFromServer(deviceId, customerId, authToken)
    .then(scheduleResp =>{
      getContent();
    })
  }
}

function getContent () {
  console.log("...Content Called...")
  if (deviceId && customerId && authToken) {
    contentObj.getContentDetailsFromServer(deviceId, customerId, authToken)
  }
}

function setWatcher() {
  // intervalObj = setInterval((s1, s2) => {
    // console.log(s1 +' '+ s2);
  // }, 500, "...", "Interviewing the interval.");
}

function downloadCustomerLandscapeImage () {
  if (customerId && authToken) {
    deviceObj.downloadDefaultImageFromServer(customerId, authToken,true)
    .then(res =>{
      downloadCustomerPotraitImage();
    })
    
  }
}

function downloadCustomerPotraitImage () {
  if (customerId && authToken) {
    deviceObj.downloadDefaultImageFromServer(customerId, authToken,false)
    .then(res =>{
      getSchedule();
    })
    
  }
}