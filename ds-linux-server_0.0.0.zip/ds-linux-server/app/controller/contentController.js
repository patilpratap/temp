/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can save & get layout details.
 * DATE: April 09, 2019.
**/

'use strict';

const fs = require('fs'),
  _ = require('lodash'),
  Path = require('path'),
  _axios = require("axios"),
  moment = require('moment'),
  BaseModel = require('../model/baseModel'),
  contentModel = require('../model/contentModel'),
  logModel = require('../model/logModel.js'),
  md5File = require('md5-file/promise');

let deviceId, customerId, authToken,contentObj = [];

exports.getContentDetailsFromServer = async (device, customer, token) => {
  let tempContentObj=[];
  deviceId = device, customerId = customer, authToken = token
  const filteredScheduleModel = contentModel.getServerRecordsFromJson("schedule.json")
  if (
    typeof filteredScheduleModel == "object" && 
    filteredScheduleModel.layouts.length
  ) {
    const layoutsObj = contentModel.getDistinctLayoutsFromScheduleInfo(filteredScheduleModel.layouts, "layoutId")
    _.forEach(layoutsObj, (layout, key) => {
      let name = "layout_" + layout.layoutId + ".json",
        filteredLayoutModel = contentModel.getServerRecordsFromJson(name);
      
      if (
        typeof filteredLayoutModel == "object" && 
        filteredLayoutModel.regions.length
      ) {
        _.forEach(filteredLayoutModel.regions, (region, key) => {
          if (typeof region == "object") {
            _.forEach(region.globalRegionContentPlaylistContents, (content, key) => {
              tempContentObj.push(content)
            })
          }
        })
      }
      if (
        typeof filteredLayoutModel == "object" && 
        filteredLayoutModel.audios != null
      ) {
        _.forEach(filteredLayoutModel.audios, (content, key) => {
          if (typeof content == "object") {
            tempContentObj.push(content)
          }
        })
      }
      if (
        typeof filteredLayoutModel == "object" && 
        filteredLayoutModel.backgroundImageContentId && filteredLayoutModel.backgroundImageContentVersionId
      ){
        let contObj={};
        contObj['contentId'] = filteredLayoutModel.backgroundImageContentId;
        contObj['contentVersionId'] = filteredLayoutModel.backgroundImageContentVersionId;
        tempContentObj.push(contObj);
      }
    })
    contentObj = tempContentObj;
    if (contentObj.length) {
      let contents = contentModel.getDistinctContentsFromLayoutsInfo(contentObj, "contentId", "contentVersionId")
      _.forEach(contents, (content, key) => {
        if (content.contentId && content.contentVersionId) {
          getContentFromServer(content.contentId, content.contentVersionId)
        }
      })
    }
  }
  else {
    // BaseModel.successResponse(res, null)
  }
}

exports.getContentDetailsFromServerAndUpdateToJson = async function (req, res) {
  BaseModel.setHeader(req.headers);
  var header = BaseModel.getHeader(),
    contentId = req.params.contentId,
    versionId = req.params.versionId,
    apiUrl = '', data, fileName = '', response;
  apiUrl = contentModel.getContentApiUrl() + contentId + '/' + versionId;
  BaseModel.getResponseFromServer(apiUrl, header)
    .then(function (contentResponse) {
      data = contentResponse.data.result;
      data['localContentUrl'] = null;
      if (data.mediaUrl) {
        fileName = 'content_' + contentId +'_'+versionId+ '.' + data.fileExtension;
        return BaseModel.downloadFile(BaseModel.getContentPath(), data.mediaUrl, fileName)
      } else {
        response = contentModel.saveServerRecordsInJson("content_" + contentId +'_'+versionId+ ".json", data)
        BaseModel.successResponse(res, response)
      }

    })
    .then(function (downloadResponse) {
      data['localContentUrl'] = BaseModel.getDeviceHosting() + "/content/" + fileName
      response = contentModel.saveServerRecordsInJson("content_" + contentId +'_'+versionId+ ".json", data)
      BaseModel.successResponse(res, response)
    })
    .catch(function (err) {
      if (err.response && err.response.data){
        logModel.setLog(true,apiUrl,err.response.data)
        BaseModel.errorResponse(res, err.response.data)
      }
      
    })
}

exports.getContentDetailsById = async function (req, res) {
  var contentId = req.params.contentId,
    versionId = req.params.versionId;
  if (contentId)
    var contentObj = contentModel.getServerRecordsFromJson("content_" + contentId +"_"+versionId+ ".json");
  let absPath = Path.resolve(BaseModel.getContentPath() + '/' + "content_" + contentId +"_"+versionId);
  if (typeof contentObj == "object") {
    let fileName = absPath+'.'+contentObj.fileExtension;
    md5File(fileName)
    .then(function(md5Hex){
      if(md5Hex.toLowerCase().trim() == contentObj.mediaHex.toLowerCase().trim()){
        BaseModel.successResponse(res, contentObj)
      }else{
        BaseModel.successResponse(res, null)
      }
    })
    .catch(function(err){
      BaseModel.successResponse(res, null)
    })
  } else {
    BaseModel.successResponse(res, null)
  }
}

function getContentFromServer(contentId, version) {
  let finalContentObj, mediaName, apiUrl,
    name = "content_"+ contentId +"_"+ version +".json",
    filteredContentModel = contentModel.getServerRecordsFromJson(name);
    
  if (typeof filteredContentModel == "string") {
    contentModel.setHeaders(customerId, authToken)
    let header = contentModel.fetchHeader();
    apiUrl = contentModel.getContentApiUrl() + contentId + '/' + version;
    BaseModel.getResponseFromServer(apiUrl, header).then(function (contentRes) {
      finalContentObj = contentRes.data.result
      finalContentObj['localContentUrl'] = null;
      mediaName = "content_"+ contentId +"_"+ version +"."+ finalContentObj.fileExtension;
      var absPath = Path.resolve(BaseModel.getContentPath() + '/' + mediaName);
      if (finalContentObj.mediaUrl && !(fs.existsSync(absPath))) {
        return BaseModel.downloadFile(BaseModel.getContentPath(), finalContentObj.mediaUrl, mediaName,apiUrl,contentId)
      }
      else {
        //let logRes = logModel.setLog(false,apiUrl)
        let response = contentModel.saveServerRecordsInJson(name, finalContentObj);
      }
    })
    .then(function (downloadRes) {
      //let logRes = logModel.setLog(false,apiUrl)
      finalContentObj['localContentUrl'] = BaseModel.getDeviceHosting() + "/content/" + mediaName
      let response = contentModel.saveServerRecordsInJson(name, finalContentObj);
    })
    .catch(function (err) {
      if (err.response && err.response.data) {
        logModel.setLog(true,apiUrl,err.response.data);
        if(err.response.status == 500){
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,contentId,0)
        }
      }else{
        logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,contentId,0)
      }
    })
  }
}