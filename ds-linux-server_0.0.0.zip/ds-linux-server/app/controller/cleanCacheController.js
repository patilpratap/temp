/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: This file is used to delete the json file.
 * DATE: April 09, 2019.
**/

'use strict';

const fs = require('fs'),
  path = require('path'),
  baseModel = require('../model/baseModel'),
  DeviceInfo = require('../model/deviceInfoModel');

exports.deleteAllCacheInformation = async function(req, res) {
  DeviceInfo.resetDeviceConfigurationModel()
  let jsonFolder = baseModel.getJsonFilePath(),
    contentFolder = baseModel.getContentPath(),
    deviceFolder = baseModel.getDevicePath();
  removeFileFromFolder(jsonFolder);
  removeFileFromFolder(contentFolder);
  removeFileFromFolder(deviceFolder);
  res.send(
  {
    "name": "SuccessfullyDeleted",
    "code": 200,
    "message": "Deleted Cache Content.",
    "result": null
  })
}

function removeFileFromFolder(folder){
  try {
    fs.readdir(folder, (err, files) => {
      if (err) throw err;
      for (const file of files) {
        let absolutePath = path.resolve(folder + '/' + file);
          if(fs.existsSync(absolutePath) && fs.statSync(absolutePath).isFile()){
            fs.unlink(path.join(folder, file), err => {
              if (err) 
                throw err;
            });
          }
        }
      });
  } 
  catch (e) {
    console.log('errror in clear cache=>',e)
  }
}

function removeContentOnly(folder) {
  try {
    fs.readdir(folder, (err, files) => {
      if (err) throw err;
      for (const file of files) {
        if (file == "schedule.json" || file.slice(6) == "layout") {
          let absolutePath = path.resolve(folder + '/' + file);
          if(fs.existsSync(absolutePath) && fs.statSync(absolutePath).isFile()) {
            fs.unlink(path.join(folder, file), err => {
              if (err) 
                throw err;
            });
          }
        }

        /*
        if(file != "client-info.json" && file != "server-time.json" && file != "device-config.json" && file != "device-model.json"){
          let absolutePath = path.resolve(folder + '/' + file);
          if(fs.existsSync(absolutePath) && fs.statSync(absolutePath).isFile()){
            fs.unlink(path.join(folder, file), err => {
              if (err) 
                throw err;
            });
          }
        }
        */
      }
    });
  } 
  catch (e) {
    console.log('errror in clear cache=>',e)
  }
}

exports.deleteAllContent = async function(req, res) {
  console.log('delete content only')
  let jsonFolder = baseModel.getJsonFilePath(),
    contentFolder = baseModel.getContentPath(),
    deviceFolder = baseModel.getDevicePath();
    removeContentOnly(jsonFolder);
    // removeContentOnly(contentFolder);
    // removeContentOnly(deviceFolder);
  res.send(
  {
    "name": "SuccessfullyDeleted",
    "code": 200,
    "message": "Deleted Cache Content.",
    "result": null
  })
}
