/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include model & manage core logic's.
 * DATE: April 01, 2019.
**/

'use strict';

var Task = require('../model/demoModel.js');

exports.list_all_tasks = function(req, res) {
  Task.getAllTask(function(err, taskArr) {
    if (err)
      res.send(err);
    res.send(taskArr);
  });
};

exports.create_a_task = function(req, res) {
  var new_task = new Task(req.body);
  if (!new_task.task || !new_task.status) {
    res.status(400).send({ error:true, message: 'Please provide task/status' });
  } 
  else {
    Task.createTask(new_task, function(err, task) {
      if (err)
        res.send(err);
      res.json(task);
    });
  }
};

exports.read_a_task = function(req, res) {
  Task.getTaskById(req.params.taskId, function(err, task) {
    if (err)
      res.send(err);
    res.json(task);
  });
};

exports.update_a_task = function(req, res) {
  Task.updateById(req.params.taskId, new Task(req.body), function(err, task) {
    if (err)
      res.send(err);
    res.json(task);
  });
};

exports.delete_a_task = function(req, res) {
  Task.remove( req.params.taskId, function(err, task) {
    if (err)
      res.send(err);
    res.json({ message: 'Task successfully deleted' });
  });
};