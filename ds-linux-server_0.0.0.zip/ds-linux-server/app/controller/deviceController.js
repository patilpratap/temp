/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can include model & get device details.
 * DATE: April 04, 2019.
**/

'use strict';
const fs = require('fs'),
  Device = require('../model/deviceModel.js'),
  axios = require("axios"),
  Path = require('path'),
  _ = require('lodash'),
  baseModel = require('../model/baseModel.js'),
  moment = require('moment'),
  logModel = require('../model/logModel.js'),
  shell = require('shelljs');
var absolutePath = '';

exports.updateDeviceModelAndClientConfiguration = async function (req, res) {
  let response;
  let bodyObj = req.body,
    deviceObj = bodyObj.device,
    identifier = req.params.identifier;
    if (identifier != "undefined" && typeof deviceObj == "object") {
      updateClientDeviceConfiguration({
        "identifier": identifier,
        "deviceToken": bodyObj.deviceAuthToken,
        "deviceId": (typeof deviceObj == "object") ? deviceObj.deviceId : null,
        "customerId": (typeof deviceObj == "object") ? deviceObj.customerId : null,
        "custCode": (bodyObj.custCode != "") ? bodyObj.custCode : null
      });
      
      response = Device.saveRecordsInJson("device-model.json", deviceObj)
    }
      let clientInfo = Device.getRecordsFromJson("client-info.json");
      res.send({
        "code": 1,
        "message": response,
        "result": clientInfo
      })
    /*
    fs.writeFile("assets/json/device-model.json", JSON.stringify(deviceObj), 'utf8', function (err) {
      let msg
      if (err) {
        msg = "An error occured while writing JSON Object to File.";
      }
      else {
        msg = "JSON file has been saved.";
      }
      res.send({
        "code": 1,
        "message": msg,
        "result": []
      })
    });
    */
  
}

function updateClientDeviceConfiguration(deviceInfo = {}) {
  let msg = "",
    // deviceInformationObj = require("../../assets/json/client-info.json")
    deviceInformationObj = Device.getRecordsFromJson("client-info.json");
  if (
    typeof deviceInformationObj == "object" &&
    deviceInformationObj.deviceIdentifier == deviceInfo.identifier
  ) {
    if (deviceInformationObj.hasOwnProperty("deviceId")) {
      deviceInformationObj.deviceId = deviceInfo.deviceId
    }
    if (deviceInformationObj.hasOwnProperty("customerId")) {
      deviceInformationObj.customerId = deviceInfo.customerId
    }
    if (deviceInformationObj.hasOwnProperty("deviceToken")) {
      deviceInformationObj.deviceToken = deviceInfo.deviceToken
    }
    if (deviceInformationObj.hasOwnProperty("custCode")) {
      deviceInformationObj.custCode = deviceInfo.custCode
    }
  }
  let response = Device.saveRecordsInJson("client-info.json", deviceInformationObj)
  /*
  fs.writeFile("assets/json/client-info.json", JSON.stringify(deviceInformationObj), 'utf8', function (err) {
    if (err) {
      return "An error occured while writing JSON Object to File.";
    }
    else {
      return "JSON file has been saved.";
    }
  });
  */
}

exports.getCustomerDeviceDefaultImage = async function (req, res) {
  let internetStatus = await baseModel.getNetworkInformation()
  baseModel.setHeader(req.headers);
  var apiUrl = '',
    landscape = req.query.isLandscape,
    apiUrl = Device.getDefaultImageUrl(landscape),
    identifier = req.params.identifier,
    imageName = '',absolutePath,
   imageType = (landscape == 'true') ? 'device_landscape_image' : 'device_potrait_image';
   if(!fs.existsSync(baseModel.getDevicePath())) {
    shell.mkdir('-p', baseModel.getDevicePath())
   }
   absolutePath = Path.resolve(baseModel.getDevicePath());
   let files=fs.readdirSync(absolutePath);
   _.forEach(files, (fileName) => {
     let str  = fileName.substring(0, fileName.lastIndexOf("_"));
     if(str == imageType){
      imageName = fileName;
     }
    })
    if (internetStatus != 'up') {
      logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0);
      if(imageName){
        baseModel.successResponse(res, { 'image': baseModel.getDeviceHosting() + "/content/device/" + imageName+"?v="+moment().format("ss") })
      }else{
        baseModel.successResponse(res, { 'image': null })
      }
     } else {
      downloadFile(res, apiUrl, imageType,imageName)
    }

}

function downloadFile(res, apiUrl, imageType,previousDownloadedImage) {
  let header = baseModel.getHeader(),
    imageName='';
  // Server Api Call
  baseModel.getResponseFromServer(apiUrl, header)
    .then(function (response) {
      if (response.data.result.url){
        imageName = imageType +'_'+ response.data.result.currentImageVersion + '.png';
        if(previousDownloadedImage != imageName){
          if(previousDownloadedImage)
            Device.deleteFileFromFolder(baseModel.getDevicePath(),previousDownloadedImage)
          return baseModel.downloadFile(baseModel.getDevicePath(), response.data.result.url,imageName)// This function is used to download the file into local folder
        }else{
          baseModel.successResponse(res, { 'image': baseModel.getDeviceHosting() + "/content/device/" + previousDownloadedImage+"?v="+moment().format("ss") })
        }
      }
    })
    .then(downloadResponse => {
      //logModel.setLog(false, apiUrl)
      baseModel.successResponse(res, { 'image': baseModel.getDeviceHosting() + "/content/device/" + imageName+"?v="+moment().format("ss") })
    })
    .catch(function (err) {
      if (err.response && err.response.data) {
        logModel.setLog(true, apiUrl, err.response.data)
        if (err.response.status == 401) {
          let absolutePath = Path.resolve(baseModel.getDevicePath() + '/' + previousDownloadedImage);
          if (fs.existsSync(absolutePath)) {
            err.response.data['result'] = { 'image': baseModel.getDeviceHosting() + "/content/device/" + previousDownloadedImage }
          }
          else {
            err.response.data['result'] = null
          }
          baseModel.errorResponse(res, err.response.data)
        }else if(err.response.status == 500){
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0);
          baseModel.successResponse(res, { 'image': baseModel.getDeviceHosting() + "/content/device/" + previousDownloadedImage })
        }else {
          baseModel.successResponse(res, { 'image': baseModel.getDeviceHosting() + "/content/device/" + previousDownloadedImage })
        }
      }else{
        logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
      }
    })
}

exports.getDeviceModel = async function (req, res) {
  let deviceMedel = Device.getRecordsFromJson("device-model.json")
  if (typeof deviceMedel == "object") {
    baseModel.successResponse(res, deviceMedel)
  } else
    baseModel.successResponse(res, null)
}

exports.getServerTime = async function (req, res) {
  let apiUrl = Device.getServerTimeUrl(),
  timeObj = Device.getRecordsFromJson("server-time.json"),
  internetStatus = await baseModel.getNetworkInformation();
  // check for net connection, if device is online get response from server otherwise return local data
  if (internetStatus != 'up') {
    var identifier = req.params.identifier;
    logModel.updateDeviceErrorLog(5,apiUrl,0,0)
    if (typeof timeObj == "object") {
      baseModel.successResponse(res, timeObj.result)
    } else {
      baseModel.successResponse(res, null)
    }
  } else {
    baseModel.getResponseFromServer(apiUrl)
      .then(function (response) {
        //logModel.setLog(false, apiUrl)
        let resp = Device.saveRecordsInJson("server-time.json", response.data);
        baseModel.successResponse(res, response.data.result)
      })
      .catch(function (err) {
        if (err.response && err.response.data) {
          logModel.setLog(true, apiUrl, err.response.data);
          if(err.response.status == 500){
            logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
          }
          baseModel.successResponse(res, timeObj)
        }else{
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
        }
      })
  }
}

exports.acknowledgePush = async function (req,res){
  let apiUrl = '',
  internetStatus = await baseModel.getNetworkInformation();
  apiUrl = Device.getPushAcknowledgeUrl();
  if(internetStatus == 'up'){
    baseModel.setHeader(req.headers);
    let response,
      bodyObj = req.body,
      header = baseModel.getHeader();
      baseModel.updateDataToServer(apiUrl,bodyObj,header)
      .then(function (response) {
        //logModel.setLog(false, apiUrl)
        if (response.data){
          res.send(response.data)
        }
      })
      .catch(function (err) {
        if (err.response && err.response.data) {
          logModel.setLog(true, apiUrl, err.response.data);
          if(err.response.status == 500){
            logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
          }
          baseModel.responseError(res,err.response.status,err.response.data)
        }else{
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
        }
      })
  }else{
    logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
    baseModel.noInternetResponse(res);
  }
}

exports.saveDeviceDataCollection = async function (req,res){
  let apiUrl = '',
  internetStatus = await baseModel.getNetworkInformation(),
  bodyObj = req.body,
  isRequestSendToServer = req.query.isRequestToServer;
  apiUrl = Device.getDataCollectionApiUrl();
  if((isRequestSendToServer == 'false' || isRequestSendToServer == false)){
    if(bodyObj.length)
      Device.saveRecordsInLogFile("data-collection-log.json",bodyObj);
    baseModel.responseSuccess(res,200,'success','Successfully Saved',null);
  }else{
    if(internetStatus == 'up'){
    if(bodyObj.length)
      Device.saveRecordsInLogFile("data-collection-log.json",bodyObj);
    let logObj = Device.getRecordsFromLogFile("data-collection-log.json");
    if(logObj.length){
      baseModel.setHeader(req.headers);
      let header = baseModel.getHeader();
        baseModel.saveDataToServer(apiUrl,logObj,header)
        .then(function (response) {
          let absolutePath = Path.resolve(baseModel.getLogPath() + "/data-collection-log.json"),
          contentDownloadTimePath = Path.resolve(baseModel.getLogPath() + "/content-download-time.json");

          if (fs.existsSync(absolutePath))
            Device.deleteFileFromFolder(baseModel.getLogPath(),"data-collection-log.json");
          if (fs.existsSync(contentDownloadTimePath))
            Device.deleteFileFromFolder(baseModel.getLogPath(),"content-download-time.json");
          //logModel.setLog(false, apiUrl)
          if (response.data){
            res.send(response.data)
          }
        })
        .catch(function (err) {
          if (err.response && err.response.data) {
            logModel.setLog(true, apiUrl, err.response.data);
            if(err.response.status == 500){
              logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
            }
            baseModel.responseError(res,err.response.status,err.response.data)
          }else{
            logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
          }
        })
      }else{
        baseModel.responseSuccess(res,200,'success','Nothing to upload on server',null)
      }
    }else{
      logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
      baseModel.noInternetResponse(res);
    }
  }
}

exports.getDeviceMeDetails = async(req,res) =>{
  let apiUrl = '',
  internetStatus = await baseModel.getNetworkInformation();
  apiUrl = Device.getDeviceMeApiUrl();
  if(internetStatus == 'up'){
    baseModel.setHeader(req.headers);
    let response,
      header = baseModel.getHeader();
      Device.getResponseFromSever(apiUrl,header)
      .then(function (response) {
        //logModel.setLog(false, apiUrl)
        if (response.data){
          res.send(response.data)
        }
      })
      .catch(function (err) {
        if (err.response && err.response.data) {
          logModel.setLog(true, apiUrl, err.response.data);
          if(err.response.status == 500){
            logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
          }
          baseModel.responseError(res,err.response.status,err.response.data)
        }else{
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
        }
      })
  }else{
    logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
    baseModel.noInternetResponse(res);
  }
}

exports.downloadDefaultImageFromServer = async (customerId, authToken,isLandscape) => {
  Device.setHeaders(customerId, authToken)
	let header = Device.fetchHeader(),
  apiUrl = Device.getDefaultImageUrl(isLandscape),
   imageName = '',absolutePath,
   imageType = (isLandscape == true) ? 'device_landscape_image' : 'device_potrait_image';
   if(!fs.existsSync(baseModel.getDevicePath())) {
    shell.mkdir('-p', baseModel.getDevicePath())
   }
	return new Promise(function(resolve,reject) {
    Device.getResponseFromSever(apiUrl, header)
    .then(function (response) {
      if (response.data.result.url){
        imageName = imageType +'_'+ response.data.result.currentImageVersion + '.png';
        return baseModel.downloadFile(baseModel.getDevicePath(), response.data.result.url,imageName,apiUrl,0)// This function is used to download the file into local folder
      }
		})
    .then(downloadResponse => {
      //logModel.setLog(false, apiUrl)
      resolve(true)
    })
		.catch (function (err) {
      if(err && err.response){
        logModel.setLog(true,apiUrl,err.response.data)
        if (err.response.data.code == 401) {
          return err.response.data
        }
        else {
          return err.response
        }
      }
		})
	});
}
