/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: This file is used to manage device registration details.
 * DATE: May 28, 2019.
**/

'use strict';
const registerModel = require('../model/registerModel'),
  baseModel = require('../model/baseModel.js'),
  logModel = require('../model/logModel.js');
  
exports.deviceRegistration = async function (req,res){
  let apiUrl = '',
  internetStatus = await baseModel.getNetworkInformation();
  apiUrl = registerModel.getDeviceRegistrationUrl();
  if(internetStatus == 'up'){
    baseModel.setHeader(req.headers);
    let response,
      bodyObj = req.body,
      header = baseModel.getHeader();
      registerModel.saveRecordToSever(apiUrl,bodyObj,header)
      .then(function (response) {
        //logModel.setLog(false, apiUrl);
        if (response.data){
          res.send(response.data)
        }
      })
      .catch(function (err) {
        if (err.response && err.response.data) {
          logModel.setLog(true, apiUrl, err.response.data);
          if(err.response.status == 500){
            logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
          }
          baseModel.responseError(res,err.response.status,err.response.data)
        }else{
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
          baseModel.responseError(res,500,null)
        }
      })
  }else{
    logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
    baseModel.noInternetResponse(res);
  }
}

exports.saveCustomerIdMask = async function (req,res){
  let apiUrl = '',
  internetStatus = await baseModel.getNetworkInformation();
  apiUrl = registerModel.getCustomerIdMaskUrl();
  if(internetStatus == 'up'){
    baseModel.setHeader(req.headers);
    let response,
      bodyObj = req.body,
      header = baseModel.getHeader();
      registerModel.saveRecordToSever(apiUrl,bodyObj,header)
      .then(function (response) {
        //logModel.setLog(false, apiUrl);
        if (response.data){
          res.send(response.data)
        }
      })
      .catch(function (err) {
        if (err.response && err.response.data) {
          logModel.setLog(true, apiUrl, err.response.data);
          if(err.response.status == 500){
            logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
          }
          baseModel.responseError(res,err.response.status,err.response.data)
        }else{
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
          baseModel.responseError(res,500,null)
        }
      })
  }else{
    logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
    baseModel.noInternetResponse(res);
  }
}

