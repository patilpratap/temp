/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: This file is used to add/update/delete the log related to device.
 * DATE: Jun 06, 2019.
**/

'use strict';
const fs = require('fs'),
logModel = require('../model/logModel.js'),
  path = require('path'),
  _ = require('lodash'),
  baseModel = require('../model/baseModel.js');
const FormData = require('form-data');
const exec = require('child_process').exec;
  exports.updateDeviceErrorLogToServer = async function (req,res){
    let apiUrl = '',
    internetStatus = await baseModel.getNetworkInformation();
    apiUrl = logModel.getDeviceErrorApiUrl();
    if(internetStatus == 'up'){
      baseModel.setHeader(req.headers);
      let bodyObj,
      deviceErrorObj = logModel.getRecordsFromJson("device-error-log.json"),
      header = baseModel.getHeader();
      if(deviceErrorObj){
        bodyObj = deviceErrorObj;
        baseModel.saveDataToServer(apiUrl,bodyObj,header)
        .then(function (response) {
          let absolutePath = path.resolve(baseModel.getLogPath() + "/device-error-log.json");
          if (fs.existsSync(absolutePath))
            logModel.deleteFileFromFolder(baseModel.getLogPath(),"device-error-log.json");
          logModel.setLog(false, apiUrl)
          if (response.data){
            baseModel.responseSuccess(res,200,'success','Successfully Saved.',null)
          }
        })
        .catch(function (err) {
          if (err.response && err.response.data) {
            logModel.setLog(true, apiUrl, err.response.data);
            if(err.response.status == 500){
              logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
            }
            baseModel.responseError(res,err.response.status,err.response.data)
          }else{
            logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
            baseModel.responseSuccess(res,200,'success','Timeout occur...',null)
          }
        })
      }else{
        baseModel.successResponse(res,null)
      }
    }else{
      logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
      baseModel.noInternetResponse(res);
    }
  }
  
  exports.updateDeviceLog = async function (req,res){
    let deviceContent = '',deviceLog,jsonArray=[];
    deviceLog = logModel.getRecordsFromFile("PDSLogFile.txt");
    if(!deviceLog){
        if(req.body && req.body.logText != undefined){
            deviceContent = req.body.logText;
            jsonArray = {'createdTime' : Math.round(new Date().getTime())};
            baseModel.saveRecordsInFile("PDSLogFile.txt",deviceContent);
            let path = baseModel.getLogPath()+'PDSLogFile.txt';
            if(fs.statSync(path).size){              
              baseModel.updateLogToJsonFile("device-time-log.json",jsonArray);
            }
            res.send({
                "code": 200,
                "name": "SuccessfullyUpdated",
                "message": "Device log saved.",
                "result": null
            })
        } else{
            res.send({
                "code": 400,
                "name": "error",
                "message": "invalid request",
                "result": null
            })
        }         
    }else{              
        if(req.body && req.body.logText!=undefined){
            deviceContent = deviceLog+'\n';
            deviceContent = deviceContent+'------------------------------------------------------';
            deviceContent = deviceContent+'\n';  
            deviceContent += req.body.logText;
            baseModel.saveRecordsInFile("PDSLogFile.txt",deviceContent); 
            res.send({
                "code": 200,
                "name": "SuccessfullyUpdated",
                "message": "Device log saved.",
                "result": null
            })
        }else{
            res.send({
                "code": 400,
                "name": "error",
                "message": "invalid request",
                "result": null
            })
        }
    }  
  }
  
  exports.updateDeviceLogToServer = async function (req,res){
    let apiUrl = '',
    internetStatus = await baseModel.getNetworkInformation();
    apiUrl = logModel.getDeviceLogApiUrl(); 
    if(internetStatus == 'up'){
      let bodyObj;
      if(baseModel.getFilesizeInBytes('PDSLogFile.txt')){ 
        baseModel.zipDeviceLog()
          .then(function(){
            let createdTime,
            updatedTime = baseModel.getFileUpdatedDate("PDSLogFile.txt");
            let deviceJson = baseModel.getLogFromJsonFile("device-time-log.json");
            if(deviceJson){
              createdTime = deviceJson.createdTime;
            }else{
              createdTime = updatedTime;
              updatedTime = Math.round(new Date().getTime());
            } 
            let absolutePath = path.resolve(baseModel.getLogPath() + '/PDSLogFile.zip');
            let absoluteTxtPath = path.resolve(baseModel.getLogPath() + '/PDSLogFile.txt');
            let absoluteTimeLogPath = path.resolve(baseModel.getLogPath() + '/device-time-log.json');
            bodyObj = {
              "deviceId": req.body.deviceId,
              "logFileName": "PDSLogFile",
              "logFileStartTime": createdTime, 
              "logFileEndTime": updatedTime 
            }
            var form = new FormData();
            form.append('values',JSON.stringify(bodyObj));
            if (fs.existsSync(absolutePath))
              form.append('file', fs.createReadStream(absolutePath));
            let formHeaders = form.getHeaders();
            formHeaders['Authorization'] = "Bearer "+ req.headers.authorization;
            return baseModel.saveDataToServer(apiUrl,form,formHeaders)
              .then(function (response) {
                if (fs.existsSync(absoluteTxtPath)) {
                  fs.unlinkSync(absoluteTxtPath);
                  fs.unlinkSync(absoluteTimeLogPath);
                }
                if (fs.existsSync(absolutePath)) {
                  logModel.deleteFileFromFolder(baseModel.getLogPath(),"PDSLogFile.zip");
                  // exec('rm -r ' + absolutePath, function (err, stdout, stderr) {
                  //     console.log('zip file deleted')
                  // });
                }
                //logModel.setLog(false, apiUrl)
                if (response.data){
                  res.send(response.data)
                }
              })
              .catch(function (err) {
              if (err.response && err.response.data) {
                logModel.setLog(true, apiUrl, err.response.data);
                if(err.response.status == 500){
                  logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
                }
                baseModel.responseError(res,err.response.status,err.response.data)
              }else{
                logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0);
                baseModel.responseSuccess(res,200,'success','Timeout occur...',null)
              }
            })
          }).catch(function(err){
              if (err.response && err.response.data) {
                logModel.setLog(true, apiUrl, err.response.data);
                if(err.response.status == 500){
                  logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
                }
                baseModel.responseError(res,err.response.status,err.response.data)
              }else{
                logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0);
                baseModel.responseSuccess(res,200,'success','Timeout occur...',null)
              }
          });            
      }else{
          baseModel.successResponse(res,null)
      }
    }else{
      logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
      baseModel.noInternetResponse(res);
    }
  }

  exports.updateContentPlaybackLog = async function (req,res){
    let apiUrl = '',
    internetStatus = await baseModel.getNetworkInformation(),
    bodyObj = req.body,
    isRequestSendToServer = req.query.isRequestToServer;
    apiUrl = logModel.getContentPlaybackLogApiUrl();
    if((isRequestSendToServer == 'false' || isRequestSendToServer == false)){
      if(bodyObj.length)
        logModel.saveRecordsInLogFile("content-playback-log.json",bodyObj);
      baseModel.responseSuccess(res,200,'success','Successfully Saved',null);
    }else{
      if(internetStatus == 'up'){
        if(bodyObj.length)
          logModel.saveRecordsInLogFile("content-playback-log.json",bodyObj);
        let playbackLog = logModel.getRecordsFromLogFile("content-playback-log.json");
        if(playbackLog.length){
          baseModel.setHeader(req.headers);
          let header = baseModel.getHeader();
            baseModel.saveDataToServer(apiUrl,playbackLog,header)
            .then(function (response) {
              let absolutePath = path.resolve(baseModel.getLogPath() + "/content-playback-log.json");
              if (fs.existsSync(absolutePath))
                logModel.deleteFileFromFolder(baseModel.getLogPath(),"content-playback-log.json");
              //logModel.setLog(false, apiUrl)
              if (response.data){
                res.send(response.data)
              }
            })
            .catch(function (err) {
              if (err.response && err.response.data) {
                logModel.setLog(true, apiUrl, err.response.data);
                if(err.response.status == 500){
                  logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
                }
                baseModel.responseError(res,err.response.status,err.response.data)
              }else{
                logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0);
                baseModel.responseSuccess(res,200,'success','Timeout occur...',null)
              }
            })
          }else{
            baseModel.responseSuccess(res,200,'success','Nothing to upload on server',null)
          }
        }else{
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
          baseModel.noInternetResponse(res);
        }
    }
  }

