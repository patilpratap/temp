/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can save & get planogram shedule details.
 * DATE: April 09, 2019.
**/

'use strict';
const fs = require('fs'),
  _ = require('lodash'),
	Path = require('path'),
	_axios = require("axios"),
	BaseModel = require('../model/baseModel.js'),
  layoutModel = require('../model/layoutModel'),
  logModel = require('../model/logModel.js');

exports.getLayoutDetailsFromServer = async (deviceId, customerId, authToken) => {
  const filteredScheduleModel = await layoutModel.getServerRecordsFromJson("schedule.json")
  return new Promise(function(resolve,reject) {
    if (
      typeof filteredScheduleModel == "object" && 
      filteredScheduleModel.layouts.length
    ) {
      layoutModel.setHeaders(customerId, authToken)
      let header = layoutModel.fetchHeader(),
        apiUrl, response, promises = [];
      const layoutsObj = layoutModel.getDistinctLayoutsFromScheduleInfo(filteredScheduleModel.layouts)
      _.forEach(layoutsObj, (layout, key) => {
        apiUrl = layoutModel.getLayoutApiUrl()+layout.layoutId;
        promises.push(BaseModel.getResponseFromServer(apiUrl,header))
      })
      _axios.all(promises).then(function (resObj) {
        resObj.forEach(function(layoutRes) {
          let layoutObj = layoutRes.data.result;
          if (typeof layoutObj == "object") {
            let url ='';
            url = layoutModel.getLayoutApiUrl()+layoutObj.layoutId
            //console.log('layoutResponse.data==>',url)
            response = layoutModel.saveServerRecordsInJson("layout_" + layoutObj.layoutId + ".json", layoutObj)
            //logModel.setLog(false,url)
          }
        })
        console.log('All layout json file created...')
        resolve(response)
        // BaseModel.successResponse(res, response)
      })
      .catch(function (err) {
        if (err.response && err.response.data) {
          logModel.setLog(true, apiUrl, err.response.data);
          if(err.response.status == 500){
            logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
          }
        }else{
          logModel.setLog(true, apiUrl)
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
        }
      })
    }
    else {
      // BaseModel.successResponse(res, null)
    }
  });
}

exports.getLayoutDetailsFromServerAndUpdateToJson = async function (req, res) {
	let scheduleInfo = layoutModel.getServerRecordsFromJson("schedule.json");
	let layoutDetails, promises = [], response;
	BaseModel.setHeader(req.headers);
	let header = BaseModel.getHeader();
	if (typeof scheduleInfo == "object" && scheduleInfo.layouts.length) {
		layoutDetails = layoutModel.getDistinctLayoutsFromScheduleInfo(scheduleInfo.layouts)
		for (const layout of layoutDetails) {
			let layoutId = layout.layoutId,
				apiUrl = '';
			apiUrl = layoutModel.getLayoutApiUrl() + layoutId;
			promises.push(BaseModel.getResponseFromServer(apiUrl, header))
		}
    _axios.all(promises).then(function (results) {
      results.forEach(function (layoutResponse) {
        let data = layoutResponse.data.result;
        if (typeof data == "object") {
          //logModel.setLog(false,apiUrl)
          response = layoutModel.saveServerRecordsInJson("layout_" + data.layoutId + ".json", data)
        }
      })
      BaseModel.successResponse(res, response)
    })
    .catch(function (err) {
      if (err.response && err.response.data){
        logModel.setLog(true,apiUrl,err.response.data)
        BaseModel.errorResponse(res, err.response.data)
      }
    })
	} else {
		BaseModel.successResponse(res, null)
	}
}

exports.getLayoutDetailsById = async function (req, res) {
	var layoutId = req.params.layoutId;
  if (layoutId)
		var layoutObj = layoutModel.getServerRecordsFromJson("layout_" + layoutId + ".json");
  if (typeof layoutObj == "object") {
		BaseModel.successResponse(res, layoutObj)
	} else
    BaseModel.successResponse(res, null)
}