/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can include model & get device details.
 * DATE: April 04, 2019.
**/

'use strict';

const fs = require('fs'),
  os = require('os'),
  _ = require('lodash'),
  sysInfo = require('systeminformation'),
  machineInfo = require('node-machine-id'),
  osUtil = require('node-os-utils'),
  DeviceInfo = require('../model/deviceInfoModel'),
  assert = require('assert'),
  baseModel = require('../model/baseModel'),
  logModel = require('../model/logModel.js');
var driveInfo = osUtil.drive
let msg = "",
_deviceConfigResponseObj;
 exports.getClientDeviceConfiguration = async function(req, res) {
  // CLEAR MODEL
  DeviceInfo.resetDeviceConfigurationModel()
  // SYS IDENTIFIER
  let uniqueIdentifier = await getMachineSynId()
  DeviceInfo.setDeviceConfigurationModel({
    "uniqueIdentifier": uniqueIdentifier
  })
  // OS INFORMATION.
  let osInformation = await osInfo();
  DeviceInfo.setDeviceConfigurationModel(osInformation)
  // CPU INFORMATION.
  let cpuInformations = await cpuData();
  DeviceInfo.setDeviceConfigurationModel(cpuInformations)
  // NETWORK INFORMATION.
  let networkInformations = await getNetworkInfo();
  if(networkInformations.length == 2 || networkInformations.length == 3){
    DeviceInfo.setDeviceConfigurationModel(networkInformations[1])
  }else{
    DeviceInfo.setDeviceConfigurationModel(networkInformations[0])
  }
  // SYSTEM RESOLUTION INFORMATION.
  let resolutionInformation = await getSystemResolution();
  DeviceInfo.setDeviceConfigurationModel(resolutionInformation.displays[0])
  // RAM MEMORY INFORMATION.
  DeviceInfo.setDeviceConfigurationModel({
    "appMemoryTotal": formatBytes(os.totalmem()),
    "appMemoryAvailable": formatBytes(os.freemem()),
    "appMemoryUsed": formatBytes(os.totalmem() - os.freemem())
  })

  let boardInformation = await boardInfo();
  DeviceInfo.setDeviceConfigurationModel({'boardName':boardInformation.manufacturer})
  // DISK MEMORY INFORMATION.
  let diskMemory = await getMemoryInfo();
  if (diskMemory) {
    DeviceInfo.setDeviceConfigurationModel({
      "diskMemoryTotal": diskMemory.totalGb,
      "diskMemoryAvailable": diskMemory.freeGb,
      "diskMemoryUsed": diskMemory.usedGb
    })
  }
  
  await getDeviceConfiguration();
  saveDeviceConfiguration();
  res.send({
    "code": 200,
    "name": "SuccessfullyFetched",
    "message": "Get client device configurations.",
    "result": _deviceConfigResponseObj
  })
}

async function getDeviceConfiguration () {
  _deviceConfigResponseObj = DeviceInfo.getDeviceConfigurationModel();
  
}

function saveDeviceConfiguration () {
  let clientConfigurationObj = DeviceInfo.getClientRecordsFromJson("client-info.json");
  if (typeof clientConfigurationObj == "object") {
    if (clientConfigurationObj.hasOwnProperty("deviceId")) {
      _deviceConfigResponseObj.deviceId = clientConfigurationObj.deviceId
    }
    if (clientConfigurationObj.hasOwnProperty("customerId")) {
      _deviceConfigResponseObj.customerId = clientConfigurationObj.customerId
    }
    if (clientConfigurationObj.hasOwnProperty("deviceToken")) {
      _deviceConfigResponseObj.deviceToken = clientConfigurationObj.deviceToken
    }
    if (clientConfigurationObj.hasOwnProperty("custCode")) {
      _deviceConfigResponseObj.custCode = clientConfigurationObj.custCode
    }
    if (clientConfigurationObj.hasOwnProperty("localServerIP")) {
      _deviceConfigResponseObj.localServerIP = clientConfigurationObj.localServerIP
    }
  }
  DeviceInfo.saveClientRecordsInJson("client-info.json", _deviceConfigResponseObj)
}

function formatBytes(bytes, decimals = 2) {

  if (bytes === 0) return '0 Bytes'

  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i]
}

function statPath(path) {
  try {
    return fs.statSync(path);
  } 
  catch (ex) {}
  return false;
}

async function getMachineId () {
  return await machineInfo.machineId()
}

async function getMachineSynId () {
  return await machineInfo.machineIdSync({original: true});
}

async function osInfo () {
  try {
    const data = await sysInfo.osInfo()
    return data
  }
  catch (e) {
    console.log(e)
  }
}

async function cpuData () {
  try {
    const data = await sysInfo.cpu()
      return data
    } 
    catch (e) {
    console.log(e)
  }
}

async function getNetworkInfo () {
  try {
    const data = await sysInfo.networkInterfaces()
    return data
  } 
  catch (e) {
    console.log(e)
  }
}

async function getSystemResolution () {
  try {
    const data = await sysInfo.graphics();
    return data;
  } 
  catch (e) {
    console.log(e)
  }
}

async function getMemoryInfo(){
  try {
    const data = await driveInfo.info();
    return data;
  } 
  catch (e) {
    console.log(e)
  }
}

async function boardInfo () {
  try {
    const data = await sysInfo.baseboard();
    return data;
  } 
  catch (e) {
    console.log(e)
  }
}

exports.updateClientDeviceConfiguration = async function(req, res) {
  let response,
    bodyObj = req.body,
    clientConfigurationObj = DeviceInfo.getClientRecordsFromJson("client-info.json");
  if (typeof clientConfigurationObj == "object") {
    _deviceConfigResponseObj = clientConfigurationObj;
    if (_deviceConfigResponseObj.hasOwnProperty("deviceId")) {
      _deviceConfigResponseObj.deviceId = (typeof bodyObj.deviceId == "number") ? bodyObj.deviceId : null
    }
    if (_deviceConfigResponseObj.hasOwnProperty("customerId")) {
      _deviceConfigResponseObj.customerId = (typeof bodyObj.customerId == "number") ? bodyObj.customerId : null
    }
    if (_deviceConfigResponseObj.hasOwnProperty("custCode")) {
      _deviceConfigResponseObj.custCode = (typeof bodyObj.custCode != "") ? bodyObj.custCode : null
    }
  }
  else {
    getDeviceConfiguration();
    _deviceConfigResponseObj.deviceId = bodyObj.deviceId;
    _deviceConfigResponseObj.customerId = bodyObj.customerId;
     _deviceConfigResponseObj.custCode = bodyObj.custCode;
  }
  response = DeviceInfo.saveClientRecordsInJson("client-info.json", _deviceConfigResponseObj);
  let clientRes = response = DeviceInfo.getClientRecordsFromJson("client-info.json")
  res.send({
    "code": 200,
    "name": "SuccessfullyFetched",
    "message": "Get client device configurations.",
    "result": clientRes
  })
}

exports.setLocalServerIp = async function(req, res) {
  let apiUrl = DeviceInfo.getLocalServerUrl(), 
  clientConfigurationObj = DeviceInfo.getClientRecordsFromJson("client-info.json");
  let internetStatus = await baseModel.getNetworkInformation();
  if (internetStatus != 'up') {
    logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0);
    baseModel.successResponse(res,clientConfigurationObj)
  }else{
    let response,
    bodyObj = req.body,
    header = baseModel.getHeader();
    baseModel.setHeader(req.headers);
		baseModel.updateDataToServer(apiUrl,bodyObj,header)
	  .then(function (result) {
      if (typeof clientConfigurationObj == "object") {
        _deviceConfigResponseObj = clientConfigurationObj;
        if (_deviceConfigResponseObj.hasOwnProperty("localServerIP")) {
          _deviceConfigResponseObj.localServerIP = (typeof bodyObj.localServerIP == "string") ? bodyObj.localServerIP : null
        }
      }
      response = DeviceInfo.saveClientRecordsInJson("client-info.json", _deviceConfigResponseObj)
      let clientObj = DeviceInfo.getClientRecordsFromJson("client-info.json");
      logModel.setLog(false, apiUrl)
      baseModel.successResponse(res,clientObj)
	  })
	  .catch (function (err) {
      if(err.response && err.response.data){
        if(err.response.status == 401){
          if(typeof clientConfigurationObj == "object"){
            err.response.data['result'] = clientConfigurationObj
          }else{
            err.response.data['result'] = null
          }
          baseModel.errorResponse(res, err.response.data)
        }else if(err.response.status == 500){
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0);
          baseModel.successResponse(res, clientConfigurationObj)
        }else{
          baseModel.successResponse(res, clientConfigurationObj)
        }
        logModel.updateDeviceErrorLog(logModel.deviceErrorCode.LOCAL_SERVER_CONNECTIVITY,apiUrl,0,0);
      }else{
        logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0);
        baseModel.successResponse(res, clientConfigurationObj)
      }
    })
  }
}

exports.apiVersion = async function(req,res) {
  let apiUrl = DeviceInfo.getApiVersionUrl(),
    internetStatus = await baseModel.getNetworkInformation();
  if (internetStatus == 'up') {
    baseModel.getResponseFromServer(apiUrl)
	  .then(function (result) {
      if(result && result.data){
        DeviceInfo.setApiVersionModel(result.data,internetStatus)
      }
      logModel.setLog(false, apiUrl)
      let apiVersion = DeviceInfo.getApiVersionModel();
      baseModel.successResponse(res,apiVersion)
	  })
	  .catch (function (err) {
      if (err.response && err.response.data) {
        logModel.setLog(true, apiUrl, err.response.data);
        if(err.response.status == 500){
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
        }
      }else{
        logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
      }
      DeviceInfo.setApiVersionModel({'localServer':'error'},internetStatus);
      let apiVersion = DeviceInfo.getApiVersionModel();
      baseModel.successResponse(res,apiVersion);
    })
  }else{
    DeviceInfo.setApiVersionModel({},internetStatus);
    let apiVersion = DeviceInfo.getApiVersionModel();
    logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0);
    baseModel.successResponse(res,apiVersion)
  }

}

