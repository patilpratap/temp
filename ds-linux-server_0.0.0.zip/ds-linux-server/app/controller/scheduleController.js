/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can save & get planogram shedule details.
 * DATE: April 09, 2019.
**/

'use strict';

const fs = require('fs'),
	_ = require('lodash'),
	Path = require('path'),
  moment = require('moment'),
	BaseModel = require('../model/baseModel'),
	scheduleModel = require('../model/scheduleModel'),
	logModel = require('../model/logModel.js');

exports.getScheduleDetailsFromServer = async (deviceId, customerId, authToken) => {
	scheduleModel.setHeaders(customerId, authToken)
	let header = scheduleModel.fetchHeader(),
	apiUrl = scheduleModel.getScheduleApiUrl() + deviceId,
	params = {
		"start-date": moment().subtract(1, 'days').format('YYYY-MM-DD'),
  	"end-date": moment().add(7, 'days').format('YYYY-MM-DD')
	}
	return new Promise(function(resolve,reject) {
		let res =scheduleModel.getResponseFromSever(apiUrl, header, params).then(function (res) {
      let scheduleObj = res.data.result;
			if (typeof scheduleObj == "object") {
				//let logResponse = logModel.setLog(false, apiUrl)
				let response =  scheduleModel.saveServerRecordsInJson("schedule.json", scheduleObj);
				resolve(response);
			}else {
				logModel.setLog(true, apiUrl)
				return res.data
			}
	  })
		.catch (function (err) {
      if (err.response && err.response.data) {
				logModel.setLog(true, apiUrl, err.response.data);
        if(err.response.status == 500){
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0)
        }
      }else{
				logModel.setLog(true, apiUrl)
        logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
      }
    })
	});
}

exports.getScheduleFromDevice = async function(req, res) {
	let scheduleObj = scheduleModel.getServerRecordsFromJson("schedule.json"),
	response = (typeof scheduleObj == "object") ? scheduleObj : null;
	res.status(200).send({
		"code": 200,
		"name": "SuccessfullyFetched",
		"message": "Successfully record fetched.",
		"result": response
	})
}

exports.getScheduleDetailsFromServerAndUpdate = async function(req, res) {
	BaseModel.setHeader(req.headers);
	var header = BaseModel.getHeader(),
	deviceId = req.params.deviceId,
	apiUrl = '',
	params= {
    'start-date': moment().subtract(1, 'days').format('YYYY-MM-DD'),
    'end-date': moment().add(7, 'days').format('YYYY-MM-DD')
  }
  apiUrl = scheduleModel.getScheduleApiUrl()+deviceId;
  BaseModel.getResponseFromServer(apiUrl,header,params)
  .then(function (response) {
  	let data = response.data.result;
  	if (typeof data == "object") {
			let response = scheduleModel.saveServerRecordsInJson("schedule.json", data)
	    res.send({
	      "code": 1,
	      "message": response,
	      "result": []
	    })
		}
  })
  .catch (function (err) {
  	if (err.response && err.response.data) {
			logModel.setLog(true,apiUrl,err.response.data)
      // BaseModel.errorResponse(res, err.response.data)
    }
  })
}