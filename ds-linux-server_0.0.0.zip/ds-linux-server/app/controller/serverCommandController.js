/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can include model & get device details.
 * DATE: April 04, 2019.
**/

'use strict';

const fs = require('fs'),
  os = require('os'),
  _ = require('lodash');
var exec = require('child_process').exec;

exports.setSystemSound = async function(req, res) {
  let params = req.query.mute;
  setVolumn(params,function(output){
    res.send({
      "name": "SuccessfullySaved",
      "code": 200,
      "message": 'Successfuly Saved',
      "result": []
    })
  });
 
}


exports.takeScreenshot = async function(req, res) {
  /*capture({
  url: 'http://localhost:4200/'
  }).then(screenshot => {
    fs.writeFileSync(`${__dirname}/screen.png`, screenshot)
    console.log('open example.png')
  })*/

  (async () => {

  // 1. Launch the browser
  const browser = await puppeteer.launch();

  // 2. Open a new page
  const page = await browser.newPage();

  // 3. Navigate to URL
  await page.goto('http://localhost:4200/preview');

  // 4. Take screenshot
  await page.screenshot({path: 'screenshot.png'});

  await browser.close();
  })();
 
}
function setVolumn(actionType,callback){
  // Used this command to mute/unmute Ubuntu system ----  "amixer -D pulse sset Master mute/unmute"
  // Used this command to mute/unmute Debian system ----  "amixer sset Master mute/unmute";
  let action = (actionType == true || actionType == 'true') ? 'mute':'unmute';
  exec('amixer sset Master '+action, function(error, stdout, stderr){ 
    callback(stdout); 
  });
}

exports.rebootSystem  = async function(req,res){
  reboot(function(output){
    res.send({
      "name": "SuccessfullySaved",
      "code": 200,
      "message": 'Successfuly Saved',
      "result": []
    })
  });
}

function reboot(callback){
  exec('/sbin/reboot', function(error, stdout, stderr){ 
    callback(stdout); 
  });
}

exports.browserFullScreen  = async function(req,res){
    fullScreen(function(output){
    res.send({
      "name": "SuccessfullySaved",
      "code": 200,
      "message": 'Successfuly Saved',
      "result": []
    })
  });
  
}

exports.launchApp  = async function(req,res){
    openBroswer(function(output){
      res.send({
        "name": "SuccessfullySaved",
        "code": 200,
        "message": 'Successfuly Saved',
        "result": []
      })
    });
  }

// function openBroswer(callback){
//   exec('google-chrome "http://localhost:4200/device-setup"', function(error, stdout, stderr){ 
//     callback(stdout); 
//   });
// }
// Need to use command sudo apt-get install xdotool
function fullScreen(callback){
  exec('xdotool key F11', function(error, stdout, stderr){ 
    callback(stdout); 
  });
}

exports.getDeviceAudioStatus  = async function(req,res){
  getVolumn(function(output){
    let audioStatus = (output.trim() == 'on') ? true:false 
    res.send({
      "name": "SuccessfullyFetched",
      "code": 200,
      "message": 'Successfuly Fetched',
      "result": {'isDeviceAudioEnabled':audioStatus}
    })
  });
}

function getVolumn(callback){
  // Used this command to mute/unmute Ubuntu system ----  "amixer -D pulse get Master | grep 'Right:' | awk -F'[][]' '{ print $2 }'"
  // Used this command to mute/unmute Debian system ----  "amixer get Master | grep 'Right:' | awk -F'[][]' '{ print $4 }'";

  exec("amixer get Master | grep 'Right:' | awk -F'[][]' '{ print $4 }'", function(error, stdout, stderr){ 
    callback(stdout); 
  });
}

exports.setDeviceVolumnLevel = function(req,res){
  let volumnLevel = req.body.volumnLevel;
  setVolumnLevel(volumnLevel,function(output){
    res.send({
      "name": "SuccessfullySaved",
      "code": 200,
      "message": 'Successfuly Saved',
      "result": null
    })
  });
}

function setVolumnLevel(volumnLevel,callback){
  // Used this command to mute/unmute Ubuntu system ----  "amixer -D pulse sset Master 10%+"
  // Used this command to mute/unmute Debian system ----  "amixer sset Master 10%+";

  exec("amixer sset Master "+volumnLevel, function(error, stdout, stderr){ 
    callback(stdout); 
  });
}


