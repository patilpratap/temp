/****
 * FILE: Use this file for controlling.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can save device config & get device config.
 * DATE: April 09, 2019.
**/

'use strict';
const fs = require('fs'),
  deviceConfig = require('../model/deviceConfigModel.js'),
  Path = require('path'),
  _ = require('lodash'),
	baseModel = require('../model/baseModel.js'),
	logModel = require('../model/logModel');

exports.saveDeviceServerConfiguration = async function(req, res) {
	let bodyObj = req.body;
	if (typeof bodyObj == "object") {
		let response = deviceConfig.saveServerRecordsInJson("device-config.json", bodyObj)
    res.send({
      "code": 1,
      "message": response,
      "result": []
    })
	}
}

exports.getDeviceServerConfiguration = async function(req, res) {
	let deviceConfigObj = deviceConfig.getServerRecordsFromJson("device-config.json")
	let internetStatus = await baseModel.getNetworkInformation();
	if (internetStatus != 'up') {
		if (typeof deviceConfigObj == "object") {
			deviceConfigObj['isAppOnline'] = (internetStatus == 'up') ? true : false;
			logModel.updateDeviceErrorLog(logModel.deviceErrorCode.INTERNET_NOT_AVAILABLE,apiUrl,0,0)
			baseModel.successResponse(res,deviceConfigObj)
		}else{
			baseModel.successResponse(res,null)
		}
	}else{
		baseModel.setHeader(req.headers);
		var apiUrl = '',response,
		header = baseModel.getHeader(),
		deviceId = req.query.deviceIds,
		param = {
			deviceIds:deviceId
		}
		apiUrl = deviceConfig.getDeviceConfigApiUrl();
		baseModel.getResponseFromServer(apiUrl,header,param)
	  .then(function (contentResponse) {
			var data=null;
	  	if(contentResponse.data && contentResponse.data.result){
	  		data = contentResponse.data.result[0].config;
	  		data['isAppOnline'] = (internetStatus == 'up') ? true : false
	  	}else{
	  		data = null;
			}
			response = deviceConfig.saveServerRecordsInJson("device-config.json", data)
			baseModel.successResponse(res, data)
	  })
	  .catch (function (err) {
			if(err.response && err.response.data){
        if (err.response.status == 401) {
          if(typeof deviceConfigObj == "object"){
            err.response.data['result'] = deviceConfigObj
          }else{
            err.response.data['result'] = null
          }
          baseModel.errorResponse(res, err.response.data)
				}else if(err.response.status == 500){
          logModel.updateDeviceErrorLog(logModel.deviceErrorCode.API_500_ERROR_CODE,apiUrl,0,0);
          baseModel.successResponse(res, deviceConfigObj)
        }else{
          baseModel.successResponse(res, deviceConfigObj)
        }
      }else{
				logModel.updateDeviceErrorLog(logModel.deviceErrorCode.UNKNOWN_ERROR,apiUrl,0,0)
				baseModel.successResponse(res, deviceConfigObj)
			}
	  })
	}
}
