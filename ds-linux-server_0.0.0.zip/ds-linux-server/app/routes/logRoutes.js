/****
 * FILE: Use this file to manage routing.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can include controller and define routing - GET, POST, PUT, DELETE.
 * DATE: Jun 06, 2019.
**/

'use strict';

module.exports = function(app) {

  const _logRoute = require('../controller/logController');
   
  app.route('/device/error')
    .post(_logRoute.updateDeviceErrorLogToServer)
  app.route('/device-logs')
    .put(_logRoute.updateDeviceLog)
    .post(_logRoute.updateDeviceLogToServer)

  app.route('/analytics/content-playback')
    .post(_logRoute.updateContentPlaybackLog)
  };