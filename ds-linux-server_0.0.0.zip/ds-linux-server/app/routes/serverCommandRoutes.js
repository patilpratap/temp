/****
 * FILE: Use this file to manage routing.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can include controller and define routing - GET, POST, PUT, DELETE.
 * DATE: May 20, 2019.
**/

'use strict';

module.exports = function(app) {

  const _serverCommandRoute = require('../controller/serverCommandController')
   
  app.route('/set-volumn')
    .get(_serverCommandRoute.setSystemSound)
  
  // app.route('/get-screenshot')
  //   .get(_serverCommandRoute.takeScreenshot)

  app.route('/reboot-system')
    .get(_serverCommandRoute.rebootSystem)

  // app.route('/app-launch')
  //   .get(_serverCommandRoute.launchApp)

  app.route('/app-fullscrren')
    .get(_serverCommandRoute.browserFullScreen)

  app.route('/device-audio')
    .get(_serverCommandRoute.getDeviceAudioStatus)
    
  app.route('/set-volumn-level')
  	.put(_serverCommandRoute.setDeviceVolumnLevel)
  
  };