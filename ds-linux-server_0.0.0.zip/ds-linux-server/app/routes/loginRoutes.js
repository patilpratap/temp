/****
 * FILE: Use this file to manage routing.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can include controller and define routing - GET, POST, PUT, DELETE.
 * DATE: May 28, 2019.
**/

'use strict';

module.exports = function(app) {

  const _loginRoute = require('../controller/loginController');
   
  app.route('/device/login')
    .post(_loginRoute.deviceLogin)
    
  app.route('/device/onboarding/:identifier')
    .get(_loginRoute.deviceOnboard)
 
};