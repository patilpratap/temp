/****
 * FILE: Use this file to manage routing.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can include controller and define routing - GET, POST, PUT, DELETE.
 * DATE: April 04, 2019.
**/

'use strict';

module.exports = function(app) {

  const _deviceRoute = require('../controller/deviceController'),
    _deviceInfoRoute = require('../controller/deviceInfoController'),
    _deviceConfigRoute = require('../controller/deviceConfigController');
  
  app.route('/device-info')
    .get(_deviceInfoRoute.getClientDeviceConfiguration)
    .put(_deviceInfoRoute.updateClientDeviceConfiguration)
  
  app.route('/device-model/:identifier?')
    .get(_deviceRoute.getDeviceModel)
    .put(_deviceRoute.updateDeviceModelAndClientConfiguration);
  
  app.route('/device-image/:identifier?')
    .get(_deviceRoute.getCustomerDeviceDefaultImage)
  
 	app.route('/device-config')
  	.get(_deviceConfigRoute.getDeviceServerConfiguration)
  	.post(_deviceConfigRoute.saveDeviceServerConfiguration)

  app.route('/time/:identifier?')
    .get(_deviceRoute.getServerTime)
  
  app.route('/device/set-local-server')
    .put(_deviceInfoRoute.setLocalServerIp);

  app.route('/api-version')
    .get(_deviceInfoRoute.apiVersion);
  
  app.route('/push/acknowledge')
    .put(_deviceRoute.acknowledgePush);

  app.route('/data-collection')
    .post(_deviceRoute.saveDeviceDataCollection);

  app.route('/device/me')
    .get(_deviceRoute.getDeviceMeDetails);

  };