/****
 * FILE: Use this file to manage routing.
 * AUTHOR: Impressico(Abhishek Kumar).
 * DESCRIPTION: In this file you can include controller and define routing - GET, POST, PUT, DELETE.
 * DATE: April 04, 2019.
**/

'use strict';

module.exports = function(app) {

  const _scheduleRoute = require('../controller/scheduleController');
   
  app.route('/schedule/:deviceId')
    .put(_scheduleRoute.getScheduleDetailsFromServerAndUpdate)

  app.route('/schedule/:deviceId')
  	.get(_scheduleRoute.getScheduleFromDevice)
   
};