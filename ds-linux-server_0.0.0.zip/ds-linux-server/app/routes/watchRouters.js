/****
 * FILE: Use this file to manage watch feature of application.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can manage all watch feature of the application like - 
 *    1. Get schedule and save it in json.
 *    2. Get layout and save it in json.
 *    3. Get content and save it in json.
 * DATE: April 12, 2019.
**/

'use strict';

module.exports = function(app) {
  var _watcher = require('../controller/watchController');

  app.route("/start-watcher")
    .get(_watcher.startWatchers);

  app.route("/stop-watcher")
    .get(_watcher.stopWatchers);
}