/****
 * FILE: Use this file to manage routing.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include controller and define routing - GET, POST, PUT, DELETE.
 * DATE: April 01, 2019.
**/

'use strict';

module.exports = function(app) {

  var _route = require('../controller/demoController');
  
  // todoList Routes
  app.route('/demo')
    .get(_route.list_all_tasks)
    .post(_route.create_a_task);
     
  app.route('/demo/:taskId')
    .get(_route.read_a_task)
    .put(_route.update_a_task)
    .delete(_route.delete_a_task);
};