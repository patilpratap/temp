/****
 * FILE: Use this file to manage node configuration.
 * AUTHOR: Impressico(fb/gshukla67).
 * DESCRIPTION: In this file you can include the rest of your app's specific main process like env, routing, body, error etc.
 * DATE: April 01, 2019.
**/

const Express = require('express'),
  Path = require('path'),
  Morgan = require('morgan'),
  BodyParser = require('body-parser');

const app = Express(),
  demoRoutes = require('./app/routes/demoroutes'),
  deviceRoutes = require('./app/routes/deviceRoutes'),
  watchRouters = require('./app/routes/watchRouters'),
  layoutRoutes = require('./app/routes/layoutRoutes'),
  contentRoutes = require('./app/routes/contentRoutes'),
  scheduleRoutes = require('./app/routes/scheduleRoutes'),
  cleanCacheRoutes = require('./app/routes/cleanCacheRoutes');
  serverCommandRoutes = require('./app/routes/serverCommandRoutes');
  loginRoutes = require('./app/routes/loginRoutes');
  registerRoutes = require('./app/routes/registerRoute');
  logRoutes = require('./app/routes/logRoutes');

// ENV.
app.use(Morgan('dev'));
// ACCESS /assets.
app.use(Express.static(Path.join(__dirname,'/assets')));
// BODY PARSER.
app.use(BodyParser.urlencoded({ extended: true }));
app.use(BodyParser.json())
// CRUD.
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization,customerId");
  if (req.method === 'OPTIONS') {
    res.header("Access-Control-Allow-Methods", "GET, PUT, POST, PATCH, DELETE, OPTIONS");
    return res.status(200).json({});
  }
  next();
});

// ROUTE.
app.get('/', function (req, res) {
  res.send(`<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><style>body {background: #555;}.content {max-width: 550px;margin: auto;background: white;padding: 10px;margin-top: 270px;}</style></head><body><div class="content"><h1>PANASONIC - LINUX APPLICATION</h1></div></body></html>`)
});
demoRoutes(app);
deviceRoutes(app);
watchRouters(app);
layoutRoutes(app);
contentRoutes(app);
scheduleRoutes(app);
cleanCacheRoutes(app);
serverCommandRoutes(app);
loginRoutes(app);
registerRoutes(app);
logRoutes(app);
// ERROR HNDL.
app.use((req, res, next) => {
  const error = new Error('Not Found!!!');
  error.status = 404;
  next(error);
})
.use((err, req, res, next) => {
  res.status(err.status || 500);
  res.json({
    error: {
      message: err.message
    }
  });
});

module.exports = app;